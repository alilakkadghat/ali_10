package array;
import java.util.*;
/*Question 2
Write a program to accept the year of graduation from school as an integer value from, the user. Using the Binary Search technique on the sorted array of integers given below.
Output the message “Record exists�? If the value input is located in the array. If not, output the message “Record does not exist�?.
{1982, 1987, 1993, 1996. 1999, 2003, 2006, 2007, 2009, 2010}.  */
class grad2{
    public static void main(){
        int  i,pos,year[ ]={1982, 1987, 1993, 1996,1999, 2003, 2006, 2007, 2009, 2010},src;
        Scanner ob=new Scanner(System.in);
        System.out.println("Enter year of Graduation :");
        src = ob.nextInt( );
        int lv=0,uv=year.length-1,mid;
        while(lv<=uv)
        {
             mid=(lv+uv)/2;
             if(year[mid]==src){
             System.out.println("Record exit");
                System.exit(0);
            }
          else if(src<year[mid])
                uv=mid-1;
            else if(src>year[mid])
                lv=mid+1;
        }
           System.out.println("roll no does not exist");
    }
}