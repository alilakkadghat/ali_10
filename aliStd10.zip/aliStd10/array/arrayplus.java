package array;
import java.util.*;
class arrayplus
{
    public static void main()
    {
    int mark[]={2,3,4,6,7,2,6,3,4,5,8,12,10};
      int sum = 0; 
for (int i = 0; i < mark.length; i++) 
{
    sum = sum + mark[i];
}
   System.out.println("Sum of all the elements of an array: " + sum);  
}
}
