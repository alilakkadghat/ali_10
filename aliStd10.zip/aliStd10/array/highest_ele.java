package array;
/*
Question 3
Write a program to accept 10 nos. store in an One dimensional Array and print the highest 
number along with its position in the array.
 */
import java.util.*;
class highest_ele
{
    public static void main()
    {
        int i,n[]=new int[10],high=0,pos=0;
        Scanner ob=new Scanner(System.in);
        for(i=0;i<10;i++)
        {
            System.out.println("enter a no.");
            n[i]=ob.nextInt();
            if(n[i]>high)
            {
                high=n[i];
                pos=i;
            }
        }
        System.out.println("The highest element of array is "+high);
        System.out.println("The position of highest element is "+pos);
    }
}
