package array;
import java.util.*;
public class Car_binsearch
{
public static void main()
{
Scanner sc = new Scanner(System.in);

int Car_No[]={1111,2222,3333,5555,7777};
String Model[]={"Alto","City","i10","Polo","BMW"};
String Name[]={"Alpesh","Mahesh","Rakesh","Maneesh","Akshay"};
String Adress[]={"Goregaon","Malad","Kandivali","Borivali","Santacruz"};
int fv=0,Lv=Car_No.length-1,m,n,c=0;
System.out.println("enter a car no");
n = sc.nextInt();
while(fv<=Lv)
{ 
m = (fv+Lv)/2;
if (n == Car_No[m])
{
System.out.println("Model = "+Model[m]);
System.out.println("Name = "+Name[m]);
System.out.println("Adress = "+Adress[m]);
c++;
break;
}
if(n > Car_No[m])
fv = m+1;
if(n < Car_No[m])
Lv = m-1;
}
if(c == 0)
System.out.println("Car not registered");
}
}