package array;

import java.util.*;
class ICSESort
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int Marks[]= new int[5]; 
        int Roll[] = new int[5];
        for(int i = 0; i<Roll.length; i++)
        {
            System.out.println("Enter roll of student");
            Roll[i] = sc.nextInt(); 
            System.out.println("Enter marks of student");
            Marks[i] = sc.nextInt();
        }
        for(int i=1;i<Roll.length;i++) 
        {
            for(int x=0;x<Roll.length-i;x++) 
            {
                if(Marks[x] < Marks[x+1])
                {
                    int c=Roll[x];
                    Roll[x]=Roll[x+1];
                    Roll[x+1]=c;

                    int d = Marks[x];
                    Marks[x] = Marks[x+1];
                    Marks[x+1] = d;
                }
            }
        }
        for(int i=0;i<Roll.length;i++)
        {
            System.out.println(Roll[i]+"    "+Marks[i]);
        }
    }

    public static void name()
    {
        int i;
        Scanner sc = new Scanner(System.in);
        int Marks[]= new int[5]; 
        int Roll[] = new int[5];
        String N[] = new String[5];
        for(i = 0; i<Roll.length; i++)
        {
            System.out.println("Enter name of student");
            sc.next();
            N[i] = sc.nextLine();
            System.out.println("Enter roll of student");
            Roll[i] = sc.nextInt(); 
            System.out.println("Enter marks of student");
            Marks[i] = sc.nextInt();
        }

        for(i=1;i<Roll.length;i++) 
        {
            for(int x=0;x<Roll.length-i;x++) 
            {
                if(Marks[x] < Marks[x+1])
                {
                    int c=Roll[x];
                    Roll[x]=Roll[x+1];
                    Roll[x+1]=c;

                    int d = Marks[x];
                    Marks[x] = Marks[x+1];
                    Marks[x+1] = d;

                    String h = N[x];
                    N[x] = N[x+1];
                    N[x+1] = h;
                }
            }
        }

        for(i=0;i<Roll.length;i++)
        {
            System.out.println(Roll[i]+"    "+Marks[i]+"    "+N[i]);
        }
    }
}
