package array;
import java.util.*;
class location
{
public static void main()
{ 
Scanner sc = new Scanner(System.in);
int roll[ ] = {11,13,14,16,18,20,22,23,25};
int marks[ ] = {75,44,55,75,77,88,99,98,54};
String name[] = {"A","B","C","D","E","F","G","H","K"};
System.out.println("Enter marks");
int N = sc.nextInt(); // 75
boolean c = false;
int a = 0;
for(int i=0; i<roll.length; i++)
{
 if(marks[i] == N )
 {
     System.out.println(" Number present in location "+(i+1));
     c=true;
     
 }
}

if(c==false)
System.out.println("Number not present");
 }
}
