package array;
import java.util.*;
class accept_array
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
    int a[]=new int[5];
    int b[]=new int[5];
    for(int i=0;i<b.length;i++){
        System.out.println("Enter value of a ");
     a[i] = sc.nextInt();
     System.out.println("Enter value of b");
     b[i]=sc.nextInt();
    }
    for(int i=0;i<b.length;i++)
    {
        System.out.println(a[i]+"\t"+b[i]);
    }
}
}
