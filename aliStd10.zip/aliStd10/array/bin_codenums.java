package array;
import java.util.*;
class bin_codenums
{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        int i,pos,code[]={101,102,103,104,105,106,107,108,109,110};
        double cost[]={25.50,45,300.50,75.25,90,99.99,65.50,70,99.99,100};
        System.out.println("Enter a Code number to search");
        int n=sc.nextInt();
        int fv=0,lv=code.length-1,m;
        while(fv<=lv){
            m=(fv+lv)/2;
            if(n==code[m])
            {
                System.out.println(code[m]+"  "+cost[m]);
                System.exit(0);
            }
            if(n>code[m])
                fv=m+1;
            if(n<code[m])
                lv=m-1;
        }
        System.out.println("Number not found");
    }
}