package array;
/*
Question 2
Write a program to store 5 nos. in an Array Create another array which has the squared
 elements of the original array. Also print the created array.*/
class squared
{
    public static void main()
    {
        int i,org[]={1,2,3,4,5},cr[]=new int[5];
        for(i=0;i<5;i++)
        {
            cr[i]=org[i]*org[i];
        }
        System.out.println("Original Array  \t Created Array");
        for(i=0;i<5;i++)
        {
            System.out.println(org[i]+"\t\t\t\t"+cr[i]);
        }
    }
}
