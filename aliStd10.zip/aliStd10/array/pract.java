package array;
import java.util.*;
class pract{
    public static void main(){
 int a[]={5,4,75,89,76};
String b[]={"ALi","taha","aadil","wrh","murtuza"};
Scanner sc=new Scanner(System.in);
System.out.println("Enter no to search for");
int src=sc.nextInt();
for(int i=0;i<a.length;i++){
 if(a[i]==src)
 {
     System.out.println("NO: "+a[i]+"Name "+b[i]);
     System.exit(0);
    }
}
System.out.println("No such no found");
}
public static void main1(){
 int a[]=new int [5];
String b[]=new String [5];
Scanner sc=new Scanner(System.in);
System.out.println("Enter no \n Enter names");
for(int i=0;i<a.length;i++){
a[i]=sc.nextInt();
b[i]=sc.next();
    }
System.out.println("Enter no to search for");
int src=sc.nextInt();
for(int i=0;i<a.length;i++){
 if(a[i]==src)
 {
     System.out.println("NO: "+a[i]+" Name "+b[i]);
     System.exit(0);
    }
}
System.out.println("No such no found");
}
    public static void main2(){
 int a[]={5,4,75,76,85};
String b[]={"ALi","taha","aadil","wrh","murtuza"};
Scanner sc=new Scanner(System.in);
int fv=0,lv=a.length-1,m;
System.out.println("Enter no to search for");
int src=sc.nextInt();
while(fv<=lv){
    m=(fv+lv)/2;
 if(a[m]==src)
 {
     System.out.println("NO: "+a[m]+"Name "+b[m]);
     System.exit(0);
    }
if(a[m]<src)
fv=m+1;
if(a[m]>src)
lv=m-1;
}
System.out.println("No such no found");
}
}