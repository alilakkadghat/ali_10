package array;

/*Question 5
Write a program to accept 3 nos. and store it  in a single subscripted variable and 
print the sum and product of the elements of the array.
*/ 
import java.util.*;
class sum_produvct
{
    public static void main()
    {
        int i,j, n[]=new int[3],sum=0,prod=1;
        Scanner ob=new Scanner(System.in);
        for(i=0;i<=2;i++)
        {
            System.out.println("enter a no.");
            n[i]=ob.nextInt();
            sum=sum+n[i];
            prod=prod*n[i];
        }
        System.out.println("The sum of elements of array are   "+sum);
        System.out.println("The product of elements of array are  "+prod);
    }
   
}
