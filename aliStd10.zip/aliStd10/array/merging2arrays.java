package array;
/*
Question 4
Write a program to store 3 numbers in each array A and array B. 
Merge the elements of Array A and Array B into array C 
such elements of Array A is stored first followed by the
 elements of Array B . Print the elements of Array C.
*/
import java.util.*;
class merging2arrays
{
    public static void main()
    {
        int i,x,A[]=new int[3],B[]=new int[3],C[]=new int[6];
        Scanner ob=new Scanner(System.in);
        for(i=0;i<3;i++)
        {
            System.out.println("enter elements for array A ");
            A[i]=ob.nextInt();
            C[i]=A[i];//index value stored 0,1,2
        }
        for(i=0,x=3;i<3;i++,x++)
      
        {
            System.out.println("enter elements for array B ");
            B[i]=ob.nextInt();
            C[x]=B[i];//index value stored 3,4,5
        }
              
        System.out.println("After merging the elements of Array C are");
        for(i=0;i<6;i++)
        {
            System.out.println(C[i]);
        }
    }
}
