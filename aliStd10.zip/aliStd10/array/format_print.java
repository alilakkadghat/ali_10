package array;
/*
Question 5
Write a program to store the following numbers in a One dimensional Array and print it in the format specified.
1,2,3,4,5,6,7,8,9,10
Output format
1	2	3
4	5	6
7	8	9
10
 */
import java.util.*;
class format_print
{
    public static void main()
    {
        int i,A[]={1,2,3,4,5,6,7,8,9,10},c=1;
        Scanner ob=new Scanner(System.in);
        for(i=0;i<10;i++)
        {
            if(c<=3)  
            {
                System.out.print(A[i]+"\t");
                c++;
            }
            else
            {
                System.out.println();
                --i;//important
                c=1;
            }
        }
    }
}

