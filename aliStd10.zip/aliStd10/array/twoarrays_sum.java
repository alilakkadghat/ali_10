package array;
/*
Question 3
Write a program to accept 3 numbers in each array a and array B .
 Calculate the elements of Array C
 which is the sum of the elements of array a and Array B.*/
import java.util.*;
class twoarrays_sum
{
    public static void main()
    {
        int i, A[]=new int[3],B[]=new int[3],C[]=new int[3];;
        Scanner ob=new Scanner(System.in);
        for(i=0;i<3;i++)
        {
            System.out.println("enter 2 nos for each array A and B");
            A[i]=ob.nextInt();
            B[i]=ob.nextInt();
            C[i]=A[i]+B[i];
        }
        System.out.println("the elements of array A,B,C are");
        System.out.println("Array A\t Array B \t Array C");
        for(i=0;i<3;i++)
        {
            System.out.println(A[i]+"\t"+B[i]+"\t"+C[i]);
        }
    }
}
