
package array;
import java.util.*;
class both_src{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter array size");
        int d=sc.nextInt();
        int n[]=new int[d];
        int m[]=new int[d];
        for(int i=0;i<n.length;i++){
            System.out.println("Enter Your Roll no");
            n[i]=sc.nextInt();
            System.out.println("Enter Your Marks ");
            m[i]=sc.nextInt();
        }
        System.out.println("Enter Roll no to search for");
        int search=sc.nextInt();
        for(int i=0;i<n.length;i++)
        {
            if(search==n[i]){
                System.out.println("Your Roll no:  "+n[i]+"Your marks: "+m[i]);
                System.exit(0);   
            }

        }
        System.out.println("No such element");
    }

    public static void mass(){
        Scanner sc=new Scanner(System.in);
        int n[]={2,4,6,21,23,24,29,32,36,40};
        char a[]={'a','b','c','d','e','f','g','h','i','j'};
        int fv=0,lv=n.length-1,m;
        System.out.println(" Enter a roll no. to search");
        int search=sc.nextInt();
        while(fv<=lv){
            m=(fv+lv)/2;
            if(search==n[m]){
                System.out.println("Your Roll no: "+n[m]+" Your Grade: "+a[m]);
                System.exit(0);
            }
            if(search>n[m])
                fv=m+1;
            if(search<n[m])
                lv=m-1;
        }
        System.out.println("No such element");
    }

}