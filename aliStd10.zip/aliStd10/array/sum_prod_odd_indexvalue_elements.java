package array;

/*Question 1
Write a program to accept 10 nos. and store it in a single subscripted variable and print the
sum and product of the elements stored in the odd index value of the array.
 */import java.util.*;
class sum_prod_odd_indexvalue_elements
{
    public static void main()
    {
        int i,A[]=new int[10],sum=0,prod=1;
        Scanner ob=new Scanner(System.in);
        for(i=0;i<10;i++)
        {
            System.out.println("enter a number");
            A[i]=ob.nextInt();
        }
        for(i=1;i<10;i=i+2)
        {         
            sum=sum+A[i];
            prod=prod*A[i];
        }
        System.out.println("The sum of odd index value  elements are"+sum);
        System.out.println("The product of odd index value  elements are"+prod);
    }
}
