package array;
/*
Question 2
Write a program to accept the year of graduation from school as an integer value from, the user. Using the Binary Search technique on the sorted array of integers given below.
Output the message “Record exists�? If the value input is located in the array. If not, output the message “Record does not exist�?.
{1982, 1987, 1993, 1996. 1999, 2003, 2006, 2007, 2009, 2010}.  */
import java.util.*;
class binaryGRADU
{
    public static void main( )
    {
        int  i,pos,year[ ]={1982, 1987, 1993, 1996,1999, 2003, 2006, 2007, 2009, 2010},src;
        Scanner ob=new Scanner(System.in);
        System.out.println("Enter year of Graduation :");
        src = ob.nextInt( );
        boolean b=false;
        int l=0,u=year.length-1,mid;
        while(l<=u){
            mid=(l+u)/2;   
            if(src==year[mid])
            {
                b=true;
                break;
            }
            else if(src<year[mid])
                u=mid-1;
            else if(src>year[mid])
                l=mid+1;
        }
        if(b==true)                          
            System.out.println("Record exist");
        else
            System.out.println("Record does not exist");
    }
}

