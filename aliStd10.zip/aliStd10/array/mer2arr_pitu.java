package array;
/*
Question 4
Write a program to store 3 numbers in each array A and array B. 
Merge the elements of Array A and Array B into array C 
such elements of Array A is stored first followed by the
 elements of Array B . Print the elements of Array C.
*/
import java.util.*;
class mer2arr_pitu
{
    public static void main()
    {
        int i,R[]={11,15,17,18,20};
        int M[]={75,82,94,80,99};
        int C[]=new int[R.length+M.length];
        Scanner ob=new Scanner(System.in);
        for(i=0;i<R.length;i++)
        {
            C[i]=R[i];
        }
        int x=0;
        for(i=R.length;i<C.length;i++)
        {
            C[i]=M[x++];
        }     
        System.out.println("After merging the elements of Array C are");
        for(i=0;i<C.length;i++)
        {
            System.out.println(C[i]);
        }
    }
    public static void mas()
    {
        int i,R[]={11,15,17,18,20};
        int M[]={75,82,94,80,99};
        int C[]=new int[R.length+M.length];
        Scanner ob=new Scanner(System.in);
        int x=0;
        for(i=0;i<R.length;i++)
        {
            C[i]=R[i];
            C[R.length+i]=M[x++];
        }
        System.out.println("After merging the elements of Array C are");
        for(i=0;i<C.length;i++)
        {
            System.out.println(C[i]);
        }
    }
}

