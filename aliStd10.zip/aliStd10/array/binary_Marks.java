package array;
import java.util.*;
class binary_Marks
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int R[] = { 11,13,14,16,18,20,22,23,25}; 
        int Mk[] = {75,44,55,66,77,88,99,100,54};
        int fv=0, lv = R.length-1, m;
        System.out.println(" Enter a roll no. to search");
        int n = sc.nextInt();  // 18 
        while(fv<=lv)
        {
            m=(fv+lv)/2;
            if(n==R[m])
            {
                System.out.println(R[m]+"  "+Mk[m]);
                System.exit(0);
            }
            if(n>R[m])
                fv=m+1;
            if(n<R[m])
                lv=m-1;
        }
       System.out.println("fv = "+fv+"      lv= "+lv);
            System.out.println("roll no does not exist");
    }
}