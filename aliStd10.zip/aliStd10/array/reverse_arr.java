package array;
import java.util.*;
class reverse_arr
{
    public static void main()
    {
    int mark[]={56,77,9,10,44,22,8,5};
for(int i=mark.length-1;i>=0;i--)
{
    System.out.println(mark[i]);
}
   
}
}
