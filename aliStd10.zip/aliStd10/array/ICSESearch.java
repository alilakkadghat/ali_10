package array;

import java.util.*;
class ICSESearch
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i;
        int Marks[]= new int[5]; 
        int roll[] = new int [5];
        for(i = 0; i<Marks.length; i++)
        {
            System.out.println("Enter roll no of student");
            roll[i] = sc.nextInt();
            System.out.println("Enter marks of student");
            Marks[i] = sc.nextInt();
        }
        System.out.println("Enter roll no of student to search");
        int n = sc.nextInt();
        for(i=0; i<Marks.length;i++) 
        {
            if(roll[i] == n)
            {
                System.out.println(roll[i]+"       "+Marks[i]); 
                System.exit(0);
            }
        }
        System.out.println(" Data not found");
    }
}
