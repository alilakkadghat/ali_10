package array;
import java.util.*;
class charactersearch
{
    public static void main()
    {
        char grade[]={'A','B','C','D','F'};
        String mark[]={"90-100","80-90","70-80","60-70","below 40"};
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your Grade");
        char n = sc.next().charAt(0);
        char y=Character.toUpperCase(n);
        for (int i = 0; i < grade.length; i++) 
        {
            if(grade[i] == y){
                 System.out.println("GRADE"+" :  "+"MARKS");
                System.out.println(grade[i]+" :   "+mark[i]);
                System.exit(0);
            }
        }
        System.out.println("not found");
    }
}
