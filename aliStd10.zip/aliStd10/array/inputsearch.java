package array;
import java.util.*;
class inputsearch
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i;
        System.out.println("Enter no of student");
        int f = sc.nextInt();
        String name[]= new String[f]; 
        int roll[] = new int [f];
        int s1[]= new int[f]; 
        int s2[] = new int [f];
        int s3[]= new int[f];
        for(i = 0; i<roll.length; i++)
        {
            System.out.println("Enter name");
            name[i] = sc.next();
            System.out.println("Enter roll no ");
            roll[i] = sc.nextInt();
            System.out.println("Enter mark in 3 subject");
            s1[i] = sc.nextInt();
            s2[i] = sc.nextInt(); 
            s3[i] = sc.nextInt();
        }
        System.out.println("Enter roll no of student to search");
        int n = sc.nextInt();
        for(i=0; i<roll.length;i++) 
        {
            if(roll[i] == n)
            {
                System.out.println(roll[i]+"\t"+name[i]+"\nmarks are:"+s1[i]+"\t"+s2[i]+"\t"+s3[i]); 
                System.exit(0);
            }
        }
        System.out.println(" Data not found");
    }
}
