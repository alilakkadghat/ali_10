package array;

/*Question 4
Write a program to accept 4 nos. and store   it in a one Dimensional array . Print 
   the sum and product of the even elements   of the array.
*/
import java.util.*;
class even_sum_prod
{
    public static void main()
    {
        int i,A[]=new int[4],sum=0,prod=1;
        Scanner ob=new Scanner(System.in);
        for(i=0;i<4;i++)
        {
            System.out.println("enter a number");
            A[i]=ob.nextInt();
            if((A[i]%2)==0)
            {
                sum=sum+A[i];
                prod=prod*A[i];
            }
        }
        System.out.println("The sum of even elements are"+sum);
        System.out.println("The product of even elements are"+prod);    
    }
}
