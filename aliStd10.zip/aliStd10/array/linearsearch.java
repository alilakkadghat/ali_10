package array;
import java.util.*;
class linearsearch
{
    public static void main()
    {
        int roll[]={11,13,14,16,18,20,22,23,25};
        int mark[]={75,44,55,75,77,88,99,100,54};
        String name[]={"ali","taha","js","icsm","jh","th","gf","yjh","rth"};
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a roll number");
        int n = sc.nextInt();
        //int c=0;
        for (int i = 0; i < roll.length; i++) //(int i = roll.length-1; i>=0 ; i--) 
        {
            if(roll[i] == n){
                System.out.println(roll[i]+"     "+mark[i]+"     "+name[i]);
                System.exit(0);
            }
        }
        System.out.println("not found");
    }
}
