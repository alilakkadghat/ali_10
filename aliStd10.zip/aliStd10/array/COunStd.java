package array;

import java.util.Scanner;

public class COunStd
{
    public static void main() {
        final int SIZE = 4;
        Scanner in = new Scanner(System.in);
        String cities[] = new String[SIZE];
        String stdCodes[] = new String[SIZE];
        System.out.println("Enter " + SIZE + "cities and their STD codes:");
        
        for (int i = 0;  i < SIZE; i++) {
            System.out.print("Enter City Name: ");
            cities[i] = in.nextLine();
            System.out.print("Enter its STD Code: ");
            stdCodes[i] = in.nextLine();
        }
        System.out.print("Enter name of city to search: ");
        String n = in.nextLine();
        
        for (int i = 0;  i< SIZE; i++) {
            if (n.equalsIgnoreCase(cities[i])) {
            System.out.println("Search Successful");
            System.out.println("City: "+cities[i]);
            System.out.println("STD Code: "+stdCodes[i]);
            System.exit(0);
            }
        }
            System.out.println("Search Unsuccessful");
    }
}