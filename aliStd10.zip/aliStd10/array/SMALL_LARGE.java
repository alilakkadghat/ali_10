package array;
import java.util.*;
class SMALL_LARGE
{
    public static void proneg()
    {

        int n[] = {5,2,-8,9,5,11,-77,9,3,0};
        int s = n[0];
        int l = n[0];           
        for(int i=1; i< n.length; i++)
        {
            if(n[i] > l)
                l = n[i];
            else if (n[i] < s)
                s = n[i];
        }
        System.out.println("Largest Number is : " + l);
        System.out.println("smallest Number is : " + s);
    }
}

