package array;
import java.util.*;
class linearlimit
{
public static void main()
{ 
Scanner sc = new Scanner(System.in);
int roll[ ] = {11,13,14,16,18,20,22,23,25};
int marks[ ] = {75,44,55,75,77,88,99,98,54};
String name[] = {"A","B","C","D","E","F","G","H","K"};
System.out.println("Enter marks limit");
int N = sc.nextInt(); // 75
//boolean c = false;
int a = 0;
for(int i=0; i<roll.length; i++)
{
 if(marks[i] <= N )
 {
     System.out.println(roll[i]+"   "+marks[i]+"     "+name[i]);
     //c=true;
     a=a+1;
 }
}
System.out.println("Frequency of students scoring below "+N+" marks = "+a);
if(a==0)
System.out.println("Number not found");
 }
}
