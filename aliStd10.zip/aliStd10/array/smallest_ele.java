package array;
/*
Question 2
Write a program to accept 10 nos. store in an One dimensional Array and print the smallest 
number along with its position in the array.
 */
import java.util.*;
class smallest_ele
{
    public static void main()
    {
        int i,n[]=new int[10],small=99999,pos=0;
        Scanner ob=new Scanner(System.in);
        for(i=0;i<10;i++)
        {
            System.out.println("enter a no.");
            n[i]=ob.nextInt();
            if(n[i]<small)
            {
                small=n[i];
                pos=i;
            }
        }
        System.out.println("The smallest element of array is "+small);
        System.out.println("The position of smallest element is "+(pos+1));
    }

}
