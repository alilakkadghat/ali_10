package array;
/*
Question 1
Program to print first 10 terms of fibonacci series.
 Fibonacci series is a series in which the first and second term remains constant as 0 and 1
 and third term onwards a term is the sum of previous term.
 0  1   1   2   3   5  . . .  . .   */ 
class FIBONACCI
{
    public static void main()
    {
        int i,n[]=new int[10];
        n[0]=0;
        n[1]=1;
        for(i=2;i<10;i++)
        {
            n[i]=n[i-1]+n[i-2];//1+0,1+1
        }
        System.out.println("Terms of  Fibonacci series are");
        /*for(i=0;i<10;i++)*/for(i=10-1;i>=0;i--)
        {
            System.out.println(n[i]);
        }
    }
}
