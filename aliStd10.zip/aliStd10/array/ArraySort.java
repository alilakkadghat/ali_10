package array;

public class ArraySort
{  
public static void main()
{
int N[]= {9,5,3,6,1};
//double N[] = {5.4,2.4,2.5,4.4,6.6,7.8,1.1};
for(int i=0;i<N.length;i++) 
{
    for(int x=0;x<N.length-1;x++) 
    {
        if(N[x] > N[x+1])
        {
            int c=N[x];
            N[x]=N[x+1];
            N[x+1]=c;
        }
    }
}
for(int i=0;i<N.length;i++)
{
System.out.println(N[i]);
}
}   
}
