package array;
import java.util.*;
class plus_onlyneg
{
    public static void sumpos()
    {
        int mark[]={-4,5,-6,2,4,-10,-8,9,-1};
        int sum = 0; 
        for (int i = 0; i < mark.length; i++) 
        {
            if(mark[i]>=0){
                sum = sum + mark[i];
            }
        }
        System.out.println("Sum of all the elements of an array: " + sum);  
    }

    public static void proneg()
    {
        int mark[]={-14,15,-16,12,14,10,-18,19,-11};
        int sum = 0,pro=1,c=0,s=0; 
        for (int i = 0; i < mark.length; i++) 
        {
            if(mark[i]>=0){
                sum = sum + mark[i];
                c++;
            }
            else{
                pro=pro*mark[i];
                s++;
            }
        }
        System.out.println("Sum of all positive no an array: " + sum);  
        System.out.println("products of all negative no in an array: " + pro);  
     System.out.println("Frequency of all positive no in an array: " + c);  
        System.out.println("Frequency of all negative no in an array: " + s);  
    }

    public static void foreach()
    {
        int mark[]={-4,5,-6,2,4,-10,-8,9,-1};
        int sum = 0; 
        for (int i :mark) 
        {
            if(i>=0){
                sum = sum + i;
            }
        }
        System.out.println("Sum of all the elements of an array: " + sum);  
    }
}
