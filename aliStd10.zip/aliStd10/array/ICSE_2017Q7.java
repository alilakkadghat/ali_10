package array;
import java.util.*;
/*
 * Write a program to input integer elements into an array of size 20 and perform the following operations: [15]
(i) Display largest number from the array.
(ii) Display smallest number’from the array.
(iii) Display sum of all the elements of the array.
 */
import java.util.*;
class ICSE_2017Q7
{
    public static void proneg()
    {
        Scanner sc = new Scanner(System.in);
        //System.out.print("Enter no. of elements you want in array:");
        int p =20; //sc.nextInt();
        int n[] = new int[p];
        System.out.println("Enter all the elements:");
        for (int i = 0; i<n.length; i++) {//accept values from user
            n[i] = sc.nextInt();
        }
        int s = n[0];
        int l = n[0];  
        int sum=0;
        for(int i=1; i< n.length; i++)
        {
            if(n[i] > l)
                l = n[i];
            else if (n[i] < s)
                s = n[i];
        }
        System.out.println("Largest Number is : " + l);
        System.out.println("smallest Number is : " + s);
        for(int i = 0; i<n.length; i++) {
            sum = sum + n[i];
        }
        System.out.println("Sum of the Numbers is:" +sum);
    }
}

