package array;
import java.util.*;
class CCS_TEST_TERM1
{
 public static void main () {
int i;
String name [] = new String [10];
long mob[]= new long [10];
Scanner sc= new Scanner (System.in);
for(i=0; i<name.length; i++){
System.out.println("Enter your name");
name [i] = sc.next();
System.out.println("Enter your mobile number");
mob[i]=sc.nextLong();
}
System.out.println("Enter student name you want to search");
String a=sc.next();
for (i = 0; i<name.length; i++) {
if( name[i].equalsIgnoreCase(a)){
System.out.println("Name :  \t Mobile number");
System.out.println(name[i]+"-"+mob[i]);
System.exit(0);
}
}
System.out.println("Name not found");
}
}
