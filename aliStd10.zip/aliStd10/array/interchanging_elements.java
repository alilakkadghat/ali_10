package array;
/*
Question 5
Write a program to store 10 numbers in an one dimensional Array ,
 interchange the first half elements of the array with the 
 second half and finally print the elements of the array 
 before and after interchanging.
*/
class interchanging_elements
{
    public static void main()
    {
        int i,A[]={1,2,3,4,5,11,12,13,14,15},t;
        System.out.println("Before interchanging the elements of array are");
        for(i=0;i<A.length;i++)
        {
            System.out.println(A[i]);
        }
        for(i=0;i<5;i++)
        {
            t=A[i];
            A[i]=A[i+5];
            A[i+5]=t;
        }
        System.out.println("After interchanging the elements of array are");
        for(i=0;i<A.length;i++)
        {
            System.out.println(A[i]);
        }
    }
}
