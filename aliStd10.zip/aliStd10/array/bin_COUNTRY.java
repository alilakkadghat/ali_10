package array;
/*
Question 1: 
Write a program to initialize the seven Wonders of the World along with their locations in two different arrays. Search for a name of the country input by the user. If found, display the name of the country along with its Wonder, otherwise display “Sorry Not Found!�?.
Seven wonders:CHICHEN ITZA, CHRIST THE REDEEMER, TAJMAHAL, 
GREAT WALL OF CHINA, MACHU PICCHU, PETRA, COLOSSEUM

Locations  : MEXICO, BRAZIL, INDIA, CHINA, PERU, JORDAN, ITALY
Example :Country Name: INDIA   Output: INDIA-TAJMAHAL
Country Name: USA   Output: Sorry Not Found!
 */
import java.util.*;
class bin_COUNTRY
{
    public static void main()
    {
        String won[] = {"England","India","Japan","Nepal","Pakistan"};
        String con[] = {"London", "New Delhi", "Tokyo", "Kathmandu", "Islamabad", "Jordan","Italy"};
        Scanner ob = new Scanner (System.in);
        System.out.println ("Enter Name of the Country ");
        String src=ob.next();
        int fv=0,lv=won.length-1,m;
        while(fv<=lv)
        {
           m=(fv+lv)/2;
           if(src.compareToIgnoreCase(won[m])==0){//src.equalsToIgnoreCase(won[m]))
               System.out.println (won[m]+"   "+con[m]);
               System.exit(0);
            }
            if(src.compareToIgnoreCase(won[m])>0){
                fv=m+1;
            }
            if(src.compareToIgnoreCase(won[m])<0){
                lv=m-1;
            }
        }
        System.out.println ("country not found");
    }
}

