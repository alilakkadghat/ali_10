package array;
import java.util.*;
class mergarr_my
{
    public static void main()
    {
        int i,x=0;
        int A[]=new int[3],B[]=new int[3],C[]=new int[A.length+B.length];
        Scanner ob=new Scanner(System.in);
        for(i=0;i<A.length;i++)
        {
            System.out.println("enter elements for array A ");
            A[i]=ob.nextInt();
            System.out.println("enter elements for array B ");
            B[i]=ob.nextInt();
            C[i]=A[i];//index value stored 0,1,2
        }
        for(i=A.length;i<C.length;i++,x++)
        {          
            C[i]=B[x];//index value stored 3,4,5
        }
        System.out.println("After merging the elements of Array C are");
        for(i=0;i<C.length;i++)
        {
            System.out.println(C[i]);
        }
    }
}
