package array;
/*
Question 3
Write a program to accept 3 Numbers and store it in a One Dimensional Array and 
print the elements of the array in reverse order.
 */
import java.util.*;
class input_rever
{
    public static void main()
    {
        int i,j, n[]=new int[3];
        Scanner ob=new Scanner(System.in);
        for(i=0;i<3;i++)
        {
            System.out.println("enter a no.");
            n[i]=ob.nextInt();
        }
        System.out.println("the elements of array in reverse order are");
        System.out.println("element\tindex value");
        for(i=2;i>=0;i--)
        {
            System.out.println(n[i]+"\t"+i);
        }
    }
}
