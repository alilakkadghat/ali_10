package array;
import java.util.*;
class for_eachloop {
    public static void main() {
        int[] age = {12, 4, 5};
        System.out.println("Using for-each Loop:");
        for(int a : age) {
            System.out.println(a);
        }
    }

    public static void mss() {
        int mark[] = {100,45,47,86,1,2,458,45};  
        Arrays.sort(mark);   
        System.out.println("Elements of array sorted in ascending order: "); 
        for(int i=mark.length-1;i>=0;i--) 
        //for (int i = 0; i < array.length; i++)   
        {       
            System.out.println(mark[i]);   
        }   
    } 

    public static void msas() {
        for(int i=1;i<=5;i++) {
            for(int x=1;x<=i;x++) 
            {       
                System.out.println(x);   
            }   
        }
    }

    public static void mwde() {
        for(int i=1;i<=5;i++) {
            for(int x=0;x<=4;x++) 
            {       
                System.out.println(x+"-"+(x+1));   
            }   
        }
    }
}
