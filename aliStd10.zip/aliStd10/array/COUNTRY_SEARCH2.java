package array;
/*
Question 1: 
Write a program to initialize the seven Wonders of the World along with their locations in two different arrays. Search for a name of the country input by the user. If found, display the name of the country along with its Wonder, otherwise display “Sorry Not Found!�?.
Seven wonders:CHICHEN ITZA, CHRIST THE REDEEMER, TAJMAHAL, 
GREAT WALL OF CHINA, MACHU PICCHU, PETRA, COLOSSEUM

Locations  : MEXICO, BRAZIL, INDIA, CHINA, PERU, JORDAN, ITALY
Example :Country Name: INDIA   Output: INDIA-TAJMAHAL
Country Name: USA   Output: Sorry Not Found!
 */
import java.util.*;
class COUNTRY_SEARCH2
{
    public static void main()
    {
        String won[] = {"Chicken Itza", "Christ The Redeemer", "Taj Mahal","Great Wall of China",    
                "Machu Picchu", "Petra Colosseum"};
        String con[] = {"Mexico", "Brazil", "India", "China", "Peru", "Jordan","Italy"};
        Scanner ob = new Scanner (System.in);
        System.out.println ("Enter Country Name whose wonder you want");
        String src=ob.next();
        int pos=0;
        for (int i=0; i<con.length; i++)
        {
            if(con[i].equalsIgnoreCase(src))
            {
                 System.out.println ("Country \t Wonder");
              System.out.println (con[i] + "\t" + won[i]);
              pos=i;
              System.out.println("position of the elment: "+(pos+1));
              System.exit(0);
            }
        }
            System.out.println ("country not found");
    }
}

