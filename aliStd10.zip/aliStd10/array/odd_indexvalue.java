package array;
/*
Question 4
Write a program to accept 5 nos. and store it in a single subscripted variable and print the
 elements stored in the odd index value  in the array.
 */
import java.util.*;
class odd_indexvalue
{
    public static void main()
    {
        int i, n[]=new int[5];
        Scanner ob=new Scanner(System.in);
        for(i=0;i<5;i++)
        {
            System.out.println("enter a no.");
            n[i]=ob.nextInt();
        }
        System.out.println("printing the element at odd index value");
        for(i=1;i<5;i=i+2)
        {
            System.out.println(n[i]);
        }
    }
}
