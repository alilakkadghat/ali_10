package array;
import java.util.*;
class mergeuneven
{
  public static void mass(){
        Scanner sc=new Scanner(System.in);
        int a[]=new int[5];
        int b[]=new int[7];
        int c[]=new int[a.length+b.length];
        int x=0;
        System.out.println("Enter Array A");
        for(int i=0;i<a.length;i++){
            a[i]=sc.nextInt();
            c[i]=a[i];
        }
        System.out.println("Enter Array B");
           for(int i=0;i<b.length;i++){
            b[i]=sc.nextInt();
        }
        for(int i=a.length;i<c.length;i++,x++){
            c[i]=b[x];
        }
        System.out.println("Array C");
        for(int i=0;i<c.length;i++){
            System.out.println(c[i]);
        }
    }
}