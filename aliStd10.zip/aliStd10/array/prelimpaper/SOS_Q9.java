package array.prelimpaper;
/*
Input three strings, say A, B, and C. In string A, search for string B and replace all occurrences of B
.--by C. . (10]
e.g. A= The brown fox jumps over the wall .
B = The
C = Tall
Output: Tall brown fox jumps over tall wall.
*/
import java.util.*;
class SOS_Q9
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter three strings");
        String a=sc.nextLine();
        String b=sc.nextLine();//the
        String c=sc.nextLine();//tall
        a=a.toLowerCase();
        b=b.toLowerCase();
        System.out.println(a.replace(b,c));
        }
        
    }
