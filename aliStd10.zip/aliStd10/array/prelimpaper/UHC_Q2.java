package array.prelimpaper;

import java.util.*;
class UHC_Q2{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        int n[]=new int[10];
        System.out.println();
        for(int i=0;i<n.length;i++){
            n[i]=sc.nextInt();
        }
        int s = n[0];
        int l = n[0];  
        for(int i=1; i< n.length; i++)
        {
            if(n[i] > l){
                l = n[i];
            }
            else if (n[i] < s)
                s = n[i];
        }
        System.out.println("Largest Number is : " + l);
        System.out.println("smallest Number is : " + s);
    }
}