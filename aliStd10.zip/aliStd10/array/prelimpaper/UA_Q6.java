package array.prelimpaper;
import java.util.*;
class UA_Q6
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine();//Sachin rame tendulkar 
s=s.toLowerCase()+" ";
String w = "",h="";
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i); 
if(ch != ' ')
w = w+ch;   
else 
{ 
    char c=Character.toUpperCase(w.charAt(0));
    h=h+c+w.substring(1)+" ";
w="";
}    
} 
System.out.println(h);     
}      
}