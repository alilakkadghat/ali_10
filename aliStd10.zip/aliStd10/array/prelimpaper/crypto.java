package array.prelimpaper;
/*
 * AD.Cryptology is a coded form of message. Write a program to input a
message from the user and print its cryptology. 
For creating a cryptology, a
message and the crypto-coding number is asked from the user. ;ASCII Code
number of each character of the message is increased by the value of
crypto-coding number and the new message is found by printing characters
of the newly codes. 
For Example:
Input: Enter a message: ABCD PQR
Enter the crypto-coding number: 3

Output: DEF STU
 */
import java.util.*;
class crypto
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a Word");//ABC
        String a=sc.nextLine();
        System.out.println("Enter crypto-coding number");
        int  b=sc.nextInt();
        int s;
         for(int i=0;i<a.length();i++){
            char ch=a.charAt(i);//A
            if(ch!=' '){
           s=(int)ch+b;
           char sh=(char)s;
               System.out.print(sh);
            }
            else
            System.out.print(" ");
    }

}
}
