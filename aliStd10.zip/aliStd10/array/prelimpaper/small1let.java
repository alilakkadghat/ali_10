package array.prelimpaper;
/*
 * Write a program to input a statement from the user in the mixed case
letters and print it in toggled case letters. (A toggled case statement
contains first letter of each word in lowercase and remaining in
uppercase)
Example: Sample Input: hello hOW aRe yOu?
Sample Output: hELLO hOW aRE yOU?
 */
import java.util.*;
class small1let
{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentence");
        String a =sc.nextLine();
        String w = "";String h = "";
        a = a.toUpperCase()+" ";
        for(int  i = 0;i<a.length();i++)
        {
            char ch = a.charAt(i);
            if (ch!=' ')
            {
                w = w+ch;
            }
            else 
            {
                char x = w.charAt(0);
                x = Character.toLowerCase(x);
                h = h+x+w.substring(1)+" ";
                w = "";

            }

        }
        System.out.println(h);
    }
}
