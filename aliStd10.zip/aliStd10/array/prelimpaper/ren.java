package array.prelimpaper;
/*
 * Define a class to declare String array of size 10 , accept words into 
the 
array and perform following operations :
● Convert each word into uppercase
● Print only those strings which begins with ‘A’ and count those 
words and print the count.
 */
import java.util.*;
class ren
{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        
        int c=0;
        String a[] =new String[10];
         for(int i=0;i<a.length;i++){
             System.out.println("Enter a word");
             a[i]=sc.next();
             a[i]=a[i].toUpperCase();
            }
        for(int i=0;i<a.length;i++){
           if(a[i].charAt(0)=='A'){
           c++;
        }
        }
                   System.out.println("Count\t"+c);

    }
}
