package array.prelimpaper;
import java.util.*;
class UA_Q5
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine();//Sachin rame tendulkar 
String w = "",h="";
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i); 
if(ch != ' '){
w = w+ch;   
}
else 
{ 
    h=h+w.charAt(0)+" ";
w="";
}    
} 
System.out.println(h+w);     
}      
}