 package array.prelimpaper;
/*
 * A cyclonic form of a word is created by converting all the characters of the 
word into capital letter before the presence of the first vowel in the word and 
small letter from first vowel. 
Write a program to input a word from the user
and print it in a cyclonic form. If no vowels are found then print it in 
uppercase letters.
For Example:
Input: psychology    Output: PSHCHology
Input: try           Output: TRY
 */
import java.util.*;
class Q15{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a Word");
        String a=sc.nextLine();
        a=a.toLowerCase()+" ";
        String w ="",p="",q="",h="";//Jaaavvvaaa
        int n=0;
        for(int i=0;i<a.length();i++){
            char ch=a.charAt(i);
            if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'){
            n=a.indexOf(ch);//5
            p=a.substring(0,n).toUpperCase();//PSHCH
            q=a.substring(n);//ology
            h=h+p+q;
            System.out.println(h);  
            System.exit(0);
        }
        }
        System.out.println(a.toUpperCase()); 
    }
}