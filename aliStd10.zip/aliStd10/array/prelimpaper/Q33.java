package array.prelimpaper;
/*
 * Write a program to input a word from the user and remove the 
duplicate characters byreplacing the sequence of duplicate characters 
by its single occurrence.
Example: INPUT –
Jaaavvvvvvvvaaaaaaaaaaa
OUTPUT – Java
 */
import java.util.*;
class Q33
{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a Word");
        String a=sc.nextLine();
        a=a+" ";
        String w ="";//Jaaavvvaaa
        for(int i=0;i<a.length()-1;i++){
            char ch=a.charAt(i);
            if(ch==a.charAt(i+1))
                continue;
            w=w+ch;//j
        }
        System.out.println(w);
    }
}