package array.prelimpaper;
import java.util.*;
class UA_Q3{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        String a[]=new String[5];
        int c=0,s=0;
        System.out.println("Enter sentences.");
        for(int i=0;i<a.length;i++){
            a[i]=sc.nextLine();  
        }
        for(int i=0;i<a.length;i++){
            if(a[i].startsWith("The"))
                c++;
            if(a[i].endsWith("India")){
            s++;
            System.out.println(a[i]);
        }
}
System.out.println("Statements begining with the word 'The' are  " +c);
System.out.println("Statements Ends with the word 'India' are  " +s);
}
}