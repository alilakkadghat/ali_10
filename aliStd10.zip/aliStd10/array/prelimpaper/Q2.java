package array.prelimpaper;
/*
 * Define a class to declare an array of size n to store names of students from 
user and store them into the array. Search for a name input by the user using 
linear search technique. Display the message “Search Successful” if the input 
name is found, otherwise display the message “NO SUCH NAME IN THE LIST”. 
For Example 1:
If names stored are: Akshay Manish, Mitesh, Sachin, Virat
Input from User: Sachin
Output: Search Successful
For Example 2:
If names stored are: Akshay Manish, Mitesh, Sachin, Virat
Input from User: Abhay
Output: NO SUCH NAME IN THE LIST
 */
import java.util.*;
class Q2
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter size of array");
        int n = sc.nextInt();
        String a[] = new String [n];
        for(int i = 0;i<n;i++)
        {
            System.out.println("enter Name");
            a[i] = sc.next();
        }
        System.out.println ("Enter Name you want to search");
        String src=sc.next();
        for (int i=0; i<a.length; i++)
        {
            if(a[i].equalsIgnoreCase(src))
            {
                System.out.println ("Search successful");
                System.exit(0);
            }
        }
        System.out.println ("name not found");
    }
}

