package array.prelimpaper;
/*
Define a class to declare a character array of size ten, 
accept the character into the array and
perform the following:
• Count the number of lowercase letters in the array and print.
• Count the number of digits in the array and print
 */
import java.util.*;
class PAWAR_Q3
{
public static void main()
{
Scanner sc = new Scanner(System.in);
char a[]=new char[10];
int c=0,s=0;
System.out.println("Enter a 10 characters");  
for(int i=0;i<a.length;i++){  
a[i] = sc.next().charAt(0);
}
for(int i=0;i<a.length;i++){  
if(Character.isLowerCase(a[i])){
c++;
}
if(Character.isDigit(a[i])){
    s++;
}
}
 System.out.println(" number of lowercase letters in the array: "+c);
  System.out.println(" number of Digits in the array: "+s);
}
}