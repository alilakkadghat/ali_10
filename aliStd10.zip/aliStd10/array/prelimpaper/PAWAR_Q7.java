package array.prelimpaper;
/*
Define a class to accept and store 10 names into 
the array and print the names which start with
‘R’ or ‘r’.
 */
import java.util.*;
class PAWAR_Q7
{
public static void main()
{
Scanner sc = new Scanner(System.in);
String a[]=new String[10];
System.out.println("Enter a 10 Strings");  
for(int i=0;i<a.length;i++){  
a[i] = sc.nextLine();
}
System.out.println("Names which start with ‘R’ or ‘r’ are:");
for(int i=0;i<a.length;i++){  
if(a[i].charAt(0)=='r'||a[i].charAt(0)=='R')
System.out.println(a[i]);
}
}
}