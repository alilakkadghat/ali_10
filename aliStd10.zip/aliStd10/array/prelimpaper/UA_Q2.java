package array.prelimpaper;
import java.util.*;
class UA_Q2{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter size of the array");
        int n=sc.nextInt();
        double a[]=new double[n];
        System.out.println("Enter NO.");
        for(int i=0;i<a.length;i++){
            a[i]=sc.nextDouble();  
        }
        System.out.println("Enter the Element you want to search");
        double b=sc.nextDouble();
        for(int i=0;i<a.length;i++){
            if(a[i]==b){
                System.out.println("Search results :  "+a[i]);
                System.exit(0);
            }
        }
        System.out.println("No Such Element ");
    }
}