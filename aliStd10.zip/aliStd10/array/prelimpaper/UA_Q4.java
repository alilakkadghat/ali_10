package array.prelimpaper;

import java.util.*;
class UA_Q4
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        long a[]=new long[25];
        System.out.println("Enter NO.");
        for(int i=0;i<a.length;i++){
            a[i]=sc.nextLong();
        }
        long sum = 0; 
        long small=a[0];//10 20 5
        for (int i = 0; i < a.length; i++) 
        {
            if(a[i]%2==1)
                sum = sum + a[i];
            if(a[i]<small){
                small=a[i];   
            }
        }
        System.out.println("Sum of odd elements of an array: " + sum);  
        System.out.println("Lowest element in the  array: " + small);  
    }
}