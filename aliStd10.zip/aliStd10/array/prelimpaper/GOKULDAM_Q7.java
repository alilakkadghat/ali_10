package array.prelimpaper;
/*
 * Define a class to accept and store 10 
 * strings into the array and perform the following:
• Convert each string into uppercase
• Print the strings which begins with “A”
 */
import java.util.*;
class GOKULDAM_Q7
{
public static void main()
{
Scanner sc = new Scanner(System.in);
String a[]=new String[10];
System.out.println("Enter a 10 Strings");  
for(int i=0;i<a.length;i++){  
a[i] = sc.nextLine();
}
for(int i=0;i<a.length;i++){  
a[i]=a[i].toUpperCase();
if(a[i].charAt(0)=='A')
System.out.println(a[i]);
}
}
}