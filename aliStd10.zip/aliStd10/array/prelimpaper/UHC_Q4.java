package array.prelimpaper;
import java.util.*;
class UHC_Q4
{
    public static void sumpos()
    {
        Scanner sc=new Scanner(System.in);
        int mark[]=new int[5];
        int sum = 0,pro=1; 
        System.out.println("Enter your data");
        for (int i = 0; i < mark.length; i++) 
        {
            mark[i]=sc.nextInt();
            sum = sum + mark[i];
            pro=pro*mark[i];
         }
        System.out.println("Sum of all the elements of an array: " + sum); 
        System.out.println("product of all the elements of an array: " + pro);  
           String s1=Integer.toString(sum);
           String s2=Integer.toString(pro);
           String s3=s1.concat(s2);
           System.out.println("Concated STRING  " + s3);  
    }
}
