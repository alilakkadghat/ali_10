package array.prelimpaper;
import java.util.*;
class H
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine();
s=s+" "; 
String w = "";
int c=0,a=0;
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i); 
if(ch>=65 && ch<=90 ||ch>=97 && ch<=122)
a++;
if(ch != ' ')
w = w+ch;   
else 
{ 
c++;
w="";
}    
} 
System.out.println("Words  "+c);    
System.out.println("Alphabets  "+a);  
}      
}