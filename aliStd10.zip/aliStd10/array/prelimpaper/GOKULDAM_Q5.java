package array.prelimpaper;
/*
 * Define a class to declare an array of size 20, 
 * accept integer elements into the array and
perform the following:
• Print the number of odd numbers present.
• Print the number of even numbers present.
 */
import java.util.*;
class GOKULDAM_Q5
{
public static void main()
{
Scanner sc = new Scanner(System.in);
int a[]=new int[20];
int c=0,s=0;
System.out.println("Enter a 10 integers");  
for(int i=0;i<a.length;i++){  
a[i] = sc.nextInt();
}
for(int i=0;i<a.length;i++){  
if(a[i]%2==0)
c++;
else
s++;
}
System.out.println("No of odd Numbers "+s);
System.out.println("No of even Numbers "+c);
}
}