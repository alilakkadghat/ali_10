package array.prelimpaper;
/*Define a class to declare a decimal array and an integer array of size n and 
accept roll numbers in integer array and height in decimal array. Search for 
roll number input by the user using linear search technique, display the roll 
number and height on screen, otherwise display the message “NO SUCH 
ELEMENT

Output: DEF STU.*/
import java.util.*;
class Q1{
    public static void main(){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter size of array");
        int n = sc.nextInt();
        int a[] = new int [n];
        double b[] = new double [n];
        for(int i = 0;i<n;i++)
        {
            System.out.println("enter roll number");
            a[i] = sc.nextInt();
            System.out.println("enter height");
            b[i]= sc.nextDouble();
        }
        System.out.println("Enter roll no you ant ot search");
        int m = sc.nextInt();
        for(int i =0;i<a.length;i++)
        {
            if(m==a[i])
            {
                System.out.println(a[i] + "    " + b[i]);
                System.exit(0);
            }
        }

        System.out.println("no such element");

    }
}