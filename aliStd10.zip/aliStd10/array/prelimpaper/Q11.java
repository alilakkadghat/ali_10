package array.prelimpaper;
/*
 * Define a class to accept a name from the user and print initials of the name 
as given in the example.
Example: 
Input: Venkatpathi Venugopal Sriramkrishana Laxman
Output: V V S Laxman
 */
import java.util.*;
class Q11{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a Word");
        String a=sc.nextLine();
        String w ="",h="";
        for(int i=0;i<a.length();i++){
            char ch=a.charAt(i);
            if(ch!=' ')
            w=w+ch;
            else{
                h=h+w.charAt(0)+" ";
                w="";
            }
        }
        System.out.println(h+" "+w); 
    }
}