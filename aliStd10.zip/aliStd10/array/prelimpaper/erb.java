package array.prelimpaper;
/*
 * Write a program to input a statement from the user and print each word
separately along with length of each word on the screen. For example:
Sample Input: I love to play football.
Sample Output: I - 1
love - 4
to - 2
play - 4
football - 8
 */
import java.util.*;
class erb
{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentence");
        String a =sc.nextLine();
        a=a+" ";
        String w="";
        for(int i=0;i<a.length();i++){
            char ch=a.charAt(i);
            if(ch!=' ')
            w=w+ch;//i love
            else{
                System.out.println(w+"\t"+w.length());
                w="";
            }
        }
        
    }
}
