package array.prelimpaper;
/*
 * Define a class to accept a full path of the file. 
 * Using Library functions, extract and
display the file path, file name and file extension
 separately as shown below.
INPUT – c:\Users\IT\Documents\Hello.docx
OUTPUT –
Path - c:\Users\IT\Documents\
File Name – Hello
Extension - .docx
 */
import java.util.*;
class Lodha_Q6
{
 public static void main(){
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter the file path");
     String s=sc.nextLine();
     int l=s.lastIndexOf('\\');
     String m=s.substring(0,l+1);
      System.out.println("Path"+m);
     int q=s.lastIndexOf('.');
     String a=s.substring(l+1,q);
     String b=s.substring(q);
  System.out.println("File Name"+a);
  System.out.println("Extension"+b);
    }
}