package array.prelimpaper;
/*
 * Define a class to input a word in lower case. Find and display the following:
• The letter with the highest ASCII value//Ali-L
• The letter with the lowest ASCII value
 */
import java.util.*;
class S_N_CQ1
{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentence");
        String a =sc.nextLine();
        a=a.toLowerCase();
        int s=0,l;
        char sh=a.charAt(0);//a
        int b=(int)sh;//97
        l=(int)sh;//97
        for(int i=1;i<a.length();i++){
            char ch=a.charAt(i);
            s=(int)ch;//105
            if(s>b)//105>97
              b=s ;
            else if(s<l)
            l=s;
        }
        System.out.println("Letter with highest  "+(char)b+"\n"+"lowest "+(char)l);
    }
}