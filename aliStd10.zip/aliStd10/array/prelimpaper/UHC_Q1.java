package array.prelimpaper;

import java.util.*;
class UHC_Q1{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        String a[]=new String[10];
        System.out.println("enter 10 strings");
        for(int i=0;i<a.length;i++){
            a[i]=sc.nextLine();
        }
        System.out.println("The strigs with even number of characters is");
        for(int i=0;i<a.length;i++){
             if(a[i].length()%2==0)
            System.out.println(a[i]);
        }
    }
}