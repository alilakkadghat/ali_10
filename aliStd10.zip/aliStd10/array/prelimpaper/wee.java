package array.prelimpaper;
/*
 * A cyclonic form of a word is created by converting all the characters of the 
word into capital letter before the presence of the first vowel in the word and 
small letter from first vowel. 
Write a program to input a word from the user
and print it in a cyclonic form. If no vowels are found then print it in 
uppercase letters.
For Example:
Input: psychology    Output: PSHCHology
Input: try           Output: TRY
 */
import java.util.*;
class wee 
{
    public static void main()
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("enter a statement");
        String v = sc.nextLine();
        v = v.toUpperCase();//PHYSCHOLOGY
        int s;String g;String h ="";
        for(int i = 0; i<v.length();i++)
        {
            char  ch = v.charAt(i);
            if(ch=='A' || ch=='E' || ch=='I' || ch == 'O' || ch == 'U')
            {
                s= v.indexOf(ch);//5
                g = v.substring(s);//OLOGY
                g = g.toLowerCase();//ology
                String b = v .substring(0,s);//physch
                h = h + b + g ;
                System.out.println(h);
                System.exit(0);
            }
        } 
        System.out.println(v);
    }
}

          
        
    
