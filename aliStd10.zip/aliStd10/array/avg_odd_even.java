package array;
import java.util.*;
class avg_odd_even
{
   public static void proneg()
    {
    int mark[]={7,3,5,6,2,9,22,4,55,66,22,11};
      int oddSum=0,evenSum=0,evenCount=0,oddCount=0;
for (int i = 0; i < mark.length; i++) 
{
      if(mark[i]%2==0){
    evenSum=evenSum+mark[i];
evenCount++;
}
else{
    oddSum=oddSum+mark[i];
oddCount++;
}
}
double avgOdd=oddSum/oddCount;  //6
double avgEven=evenSum/evenCount;
System.out.println("\nAverage of even numbers are: "+avgEven);   //7
System.out.println("\nAverage of odd numbers are: "+avgOdd);
}
}
