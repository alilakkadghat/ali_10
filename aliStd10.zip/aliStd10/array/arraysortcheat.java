package array;
import java.util.*;   
public class arraysortcheat 
{   
public static void main()   
{   
int [] array = {100,45,47,86,1,2,458,45};  
Arrays.sort(array);   
System.out.println("Elements of array sorted in ascending order: "); 
for(int i=array.length-1;i>=0;i--) 
//for (int i = 0; i < array.length; i++)   
{       
System.out.println(array[i]);   
}   
}  
}  