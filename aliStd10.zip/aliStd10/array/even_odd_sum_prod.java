package array;
/*
	Write a program to accept 10 numbers and store in a One Dimensional Array and print the 
	sum of even elements and the product of odd elements of the Array. 
*/
import java.util.*;
class even_odd_sum_prod
{
    public static void main()
    {
        int i,A[]=new int[10],sum=0,prod=1;
        Scanner ob=new Scanner(System.in);
        for(i=0;i<10;i++)
        {
            System.out.println("enter a number");
            A[i]=ob.nextInt();
            if((A[i]%2)==0)
                sum=sum+A[i];
            else
            prod=prod*A[i];
        }
        System.out.println("The sum of even elements are"+sum);
        System.out.println("The product of odd elements are"+prod);    
    }
}
