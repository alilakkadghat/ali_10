package array;
import java.util.*;
/*
Question 4
Concept of Binary Search
//NOTE BINARY SEARCH CANNOT BE PERFORMED ON STRINGS. 
// IT CAN ONLY CAN BE PERFORMED ON NUMBERS. 
// In this question we auume that the elements of array are in sorted order.
 */
class BINARY_SEARCH
{
    public static void main()
    {
        int n[]=new int[5],i,j,pos=0,src;
        boolean b=false;
        Scanner ob=new Scanner(System.in);
        for(i=0;i<5;i++)
        {
            System.out.println("enter a number");
            n[i]=ob.nextInt();
        }
        System.out.println("enter number to be searched");
        src=ob.nextInt();
        int l=0,u=4,mid; 
        //lower bound ‘l’ is the first index value
        //upper bound ‘u’ is the last index value
        while(l<=u)
        {
            mid=(l+u)/2;
            if(src==n[mid])
            {
                b=true;
                pos=mid;
                break;
            }
            else if(src<n[mid])
                u=mid-1;
            else if(src>n[mid])
                l=mid+1;
        }
        if(b==true)
        {
            System.out.println("Search Successful");
            System.out.println("elements of array are");
            for(i=0;i<5;i++)
            {
                System.out.println(n[i]);
            }
            System.out.println("Number to be searched is  : "+ src +" found at position:"+(pos+1));
        }
        else
        {
            System.out.println("Search unsuccessful ");
            System.out.println("Number not in list ");
        }
    }
}
