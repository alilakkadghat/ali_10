package array;
/*
 * Write a program to input and store roll numbers, names and marks 
 * in 3 subjects of n number students in five single 
 * dimensional array and display the remark based on 
 * average marks as given below : (The maximum marks in the subject 
 * are 100) [15]
Average marks=Total Marks/3
Average marks        Remark
85-100               Excellent
75-84                Distinction
60-74                First Class
40-59                Pass
less than 40         Poor
 */
import java.util.*;
class ICSE_2015Q6
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int i;
        System.out.println("Enter no of student");
        int f = sc.nextInt();
        String name[]= new String[f]; 
        int roll[] = new int [f];
        int s1[]= new int[f]; 
        int s2[] = new int [f];
        int s3[]= new int[f];
        for(i = 0; i<roll.length; i++)
        {
            System.out.println("Enter name");
            name[i] = sc.next();
            System.out.println("Enter roll no ");
            roll[i] = sc.nextInt();
            System.out.println("Enter mark in 3 subject");
            s1[i] = sc.nextInt();
            s2[i] = sc.nextInt(); 
            s3[i] = sc.nextInt();
        }
        
        String remark;
        for(i=0; i<roll.length;i++) 
        {
             double avg=(s1[i]+s2[i]+s3[i])/3.0;
            if(avg<40)
                remark="Poor";
            else if(avg>=40 && avg<=59)
                remark="Pass";
            else if(avg>=60 && avg<=74)
                remark="First Class";
            else if(avg>=75 && avg<=84)
                remark="Distinction";
            else 
                remark="Excellent";
            System.out.println(name[i]+"\t"+avg+"\t"+remark);
        }
    }
}
