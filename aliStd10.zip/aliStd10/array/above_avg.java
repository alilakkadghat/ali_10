package array;

/*Question 2
Write a program to accept 3 students name along with their Mathematics marks store it in   separate 
One dimensional array Print the name   along with marks of only those students who have  secured above the class average.*/
 
import java.util.*;
class above_avg
{
    public static void main()
    {
        int i, mrks[]=new int[3],tot=0;
        String nm[]=new String[3];
        double avg;
        Scanner ob=new Scanner(System.in);
        for(i=0;i<3;i++)
        {
            System.out.println("enter students name along with Maths marks");
            nm[i]=ob.nextLine();
            mrks[i]=ob.nextInt();
            ob.nextLine();
            tot=tot+mrks[i];
        }
        avg=tot/3;
        System.out.println("the average marks of maths is"+avg);
        System.out.println("the details of student/s who have secured above average are");
        System.out.println("name\tmarks");
        for(i=0;i<3;i++)
        {
            
            if(mrks[i]>avg)
                System.out.println(nm[i]+"\t"+mrks[i]);
        }
    }
}
