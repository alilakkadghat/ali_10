package array;
/*
Question 1
Write a program to accept 3 students name along  with their marks of physics, chemistry and   biology and 
store it in separate One dimensional  Array, print each students name along with their  science marks .*/
import java.util.*;
class St_detail
{
    public static void main()
    {
        int i,x,phy[]=new int[3],chem[]=new int[3],bio[]=new int[3],sci[]=new int[3];
        String name[]=new String[3];
        Scanner ob=new Scanner(System.in);
        for(i=0;i<3;i++)
        {
            System.out.println("enter students name,physics , chemistry and bio marks ");
            name[i]=ob.nextLine();
            phy[i]=ob.nextInt();
            chem[i]=ob.nextInt();
            bio[i]=ob.nextInt();
            sci[i]=(phy[i]+chem[i]+bio[i])/3;
        }
        System.out.println("students name and science marks are");
        System.out.println("Name\t Science marks");
        for(i=0;i<3;i++)
        {
            System.out.println(name[i]+"\t"+sci[i]);
        }
    }
}
