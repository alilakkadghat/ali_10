import java.util.*;
class lifehack
{
    public static void main()
    {
        //System.out.println("hello world")\u000dSystem.out.println("i am cool");
        int num=5;
        //\u000dnum=10;
        System.out.println(num);
    }
}
