import java.util.*;
      class libary_class
    {
      public static void main()
     {
      int i=9;long a=290889L;double d=89.453;
       String s="678",f="7899.4",j="7485.99";
       int n1=Integer.valueOf(s);
       double n2=Double.valueOf(j);
       String str1=String.valueOf(a);
       String str2=Integer.toString(i);
       System.out.println("interger value of s:"+n1+"\n double value of j:"+n2+"\n String value of a:"+str1+"\n STring value of i:"+str2);
                    }  
                }