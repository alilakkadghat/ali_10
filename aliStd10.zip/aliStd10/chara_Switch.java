import java.util.*;
class chara_Switch
{
    public static void main()
    {
        char ch;
        do
        {
            Scanner sc = new Scanner(System.in);
            System.out.println("    Menu    ");
            System.out.println("Type O For odd numbers series ");
            System.out.println("Type E For Even numbers series ");
            System.out.println("Type Q to Quit ");
            ch = sc.next().charAt(0);
            switch(ch)
            {
                case 'O':
                case 'o':
                System.out.println("Enter series limit ");
                int n = sc.nextInt();
                for (int i=1;i<=n;i=i+2)   
                { 
                    System.out.println(i);
                }
                break;
                case 'E':
                case 'e':
                System.out.println("Enter series limit ");
                int x = sc.nextInt();
                for (int i=2;i<=x;i=i+2)   
                { 
                    System.out.println(i); 
                }
                break;
                case 'Q':
                case 'q':
                System.out.println("Thank you........ ");
                break;
                default:
                System.out.println("Wrong Input !! ");
            }
        }while(ch != 'Q' && ch != 'q');
    }
}