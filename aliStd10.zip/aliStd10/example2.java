/*Question 1
Write a program to get following output
  5   3   1
  3   1
  1
  */
class example2
{
  public static void main9()
    {
        int i,j;
        for(i=5;i>=1;i=i-2)
        {
            for(j=i;j>=1;j=j-2)
            {
                System.out.print(j+"  ");
            }
            System.out.println();
       
        }
    }
/*Question 2
Write a program to get following output
1
1	3
1	3	5*/
  public static void main10()
    {
        int i,j;
        for(i=1;i<=5;i=i+2)
        {
            for(j=i;j>=5;j=j+2)
            {
                System.out.print(j+"  ");
            }
            System.out.println();
       
        }
    }
/*Question 3
Write a program to print 5 lines of floyd's triangle
  1  
  2  3  
  4  5  6
  7  8  9  10
  11 12 13 14 15
  */
//class floyd
  public static void main11()
    {
        int i,j,ctr=1;
        for(i=1;i<=5;i++)
        {
            for(j=1;j<=i;j++)
            {
                System.out.print(ctr+"  ");
                ctr++;
            }
            System.out.println();
       
        }
    }
/*Question 4
Write a program to get following output
  1  1  1  1  1 
  3  3  3
  5  
  */
  public static void main12()
    {
        int i,j;
        for(i=1;i<=5;i=i+2)
        {
            for(j=5;j>=i;j--)
            {
                System.out.print(i+"  ");
            }
            System.out.println();
       
        }}
 /* Question 5    
Write a program to get following output
  1
  1  4
  1  4   9
  1  4   9   16
  1  4   9   16   25
  */

 public static void main13()
    {
        int i,j;
        for(i=1;i<=5;i++)
        {
            for(j=1;j<=i;j++)
            {
                System.out.print((j*j)+" ");
            }
            System.out.println();
        }
    }
}
    
 
    
    
