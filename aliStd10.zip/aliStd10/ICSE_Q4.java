import java.util.*;
class ICSE_Q4
{
public static void proneg()
    {
        Scanner sc=new Scanner(System.in);
        double a[]=new double[5];
        double b[]=new double[5];
        double pro=1.0; 
        for (int i = 0; i < a.length; i++) 
        {
            System.out.println("enter data");
            a[i]=sc.nextDouble();
        }
         for (int i = 0; i < a.length; i++) 
        {
            pro=pro*a[i];
        }
        System.out.println(pro);
        System.out.println("Square elements are:");
             for (int i = 0; i < a.length; i++) 
        {
             b[i]=a[i]*a[i];
             System.out.println(b[i]);
        }
            }
        }
       