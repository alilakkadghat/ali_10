
import java.util.*;
/*Define a class to declare a character array of size ten, accept the character into the array
and perform the following:
• Count the number of uppercase letters in the array and print.
• Count the number of vowels in the array and print*/
class specimen_Q3{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        char ch[]=new char[10];
        int c=0,s=0;
        System.out.println("Enter 10 elements");
        for(int i=0;i<ch.length;i++){
            ch[i]=sc.next().charAt(0);
        }
        System.out.println("The upper case letters are:");
        for(int i=0;i<ch.length;i++){
            if(Character.isUpperCase(ch[i])){
                c++;
                System.out.println(ch[i]);
            }
        }
        System.out.println("The Vowels present are:");
        for(int i=0;i<ch.length;i++){
            char ah=Character.toUpperCase(ch[i]);
            if(ah=='A'||ah=='E'||ah=='I'||ah=='O'||ah=='U')
            {
                s++;
                System.out.println(ah);
            }
        }
        System.out.println("No of Uppercase letters are: "+c);
        System.out.println("No of Vowels  are: "+s);
    }
}