 
import java.util.*;
/*Define a class to accept a string, convert it into lowercase and 
 *check whether the string is a palindrome or not.
A palindrome is a word which reads the same backward as forward.
Example:
madam, racecar etc*/

class specimen_Q6
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentences");
        String s = sc.nextLine();
        String w="";
        s=s.toLowerCase(); 
        int i;
        for(i=s.length()-1;i>=0;i--){
            char ch=s.charAt(i);
            w=w+ch;
        }
        System.out.println("Original Word = "+s);
        System.out.println("Reversed Word = "+w);
        if (s.equals(w))
            System.out.println("it is a palindrome word ");
        else
            System.out.println("it is not a palindrome word");
    }
}