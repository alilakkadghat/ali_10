import java.util.*;
class test3_Q2
{
public static void main ()
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the last value");
int num=sc.nextInt();
double s=0,n=1,d=1;
for(int i=2; i<=num; i++)
{
n=n+i;//1+2=3   3+3=6
d=d*i;//1*2=2   2*3=6
s=s+(n/d);
}
System.out.println("The Sum of the series is  "+s);
}
}
