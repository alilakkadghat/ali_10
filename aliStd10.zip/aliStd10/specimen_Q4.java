 
import java.util.*;
/*Define a class to declare an array of size 20 of double datatype, accept the elements into
the array and perform the following:
• Calculate and print the sum of all the elements.
• Calculate and print the highest value of the array.*/
class specimen_Q4{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        double data[]=new double[10];
        double h=0;
        double c=0;
        System.out.println("Enter 20 elements");
        for(int i=0;i<data.length;i++){
            data[i]=sc.nextDouble();
            c=c+data[i];
            if(data[i]>h){
                h=data[i];
            }
        }
        System.out.println("The Sum of all elements: "+c);
      System.out.println("The highest value of the array: "+h);
    }
}