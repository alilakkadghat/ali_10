//Question 1
class example1 extends example2
{
public static void main1()
{
int i,j;
for(i=1;i<=2;i++)

{
for(j=-1;j>=-3;j--)
{
System.out.println("trial output");
}
}
}
/*Output :
trial output
trial output
trial output
trial output
trial output
trial output
*/
//Question 2
public static void main2()
{
int i,j;
for(i=1;i<=3;i++)
{
for(j=1;j<=3;j++)
{
System.out.println(i+" "+j);
}
}
}
/*Qutput
1 1
1 2
1 3
2 1
2 2
2 3
3 1
3 2
3 3
*/
//Question 3 :
public static void main3()
{
int i,j;
for(i=1;i<=2;i++)
{
for(j=1;j<=3;j++)
{
System.out.print("* ");
}
System.out.println();
}
/*
Output :
* * *
* * *
Question 4
Write a to get following output
*
* *
* * *
*/
}
public static void main4()
{
int i,j;
for(i=1;i<=3;i++)
{
for(j=1;j<=i;j++)
{
System.out.print("*  ");
}
System.out.println();
}
}
/*
Question 5
Write a program to get following output
* * *
* *
*
**/
public static void main5()
{
int i,j;
for(i=3;i>=1;i--)
{
for(j=1;j<=i;j++)
{
System.out.print("*  ");
}
System.out.println();
}
}
/*Question 6
Write a program to get following output
1 2 3
1 2
1
*/
public static void main6()
{
int i,j;
for(i=3;i>=1;i--)
{
for(j=1;j<=i;j++)
{
System.out.print(j+"  ");
}
System.out.println();
}
}
/*Question 7
Write a program to get following output
3 3 3
2 2
1
*/

public static void main7()
{
int i,j;
for(i=3;i>=1;i--)
{
for(j=1;j<=i;j++)
{
System.out.print(i+"  ");
}
System.out.println();
}
}
/*Question 8
Write a program to get following output
@ # @ # @
@ # @ #
@ # @
@ #
@
*/
public static void main8()
{
int i,j;
for(i=5;i>=1;i--)
{
for(j=1;j<=i;j++)
{
if((j%2)==0)
System.out.print("#");
else
System.out.print("@");

}
System.out.println();
}
}
}