 import java.util.*;
/*Define a class to accept and store 10 strings into the array 
 * and print the strings with even number of characters.*/
class specimen_Q7{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        String data[]=new String[10];
        System.out.println("Enter elements");
        for(int i=0;i<data.length;i++){
            data[i]=sc.nextLine();
        }
        System.out.println("strings with even number of characters");
        for(int i=0;i<data.length;i++){
            if(data[i].length()%2==0){
            System.out.println(data[i]);
        }
        }
    }
}