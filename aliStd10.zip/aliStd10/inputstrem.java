import java.io.*;
    class inputstrem
    {
         public static void main ()throws IOException
      {

        InputStreamReader read=new InputStreamReader(System.in);
           BufferedReader in =new BufferedReader(read);
        System.out.println("Enter a number");
            int a =Integer.valueOf(in.readLine());
            System.out.println("number inputed\t"+a);

        }
        }