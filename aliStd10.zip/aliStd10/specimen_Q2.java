import java.util.*;
/*Define a class to declare an integer array of size n and accept the elements into the array.
Search for an element input by the user using linear search technique, display the element
if it is found, otherwise display the message “NO SUCH ELEMENT.*/
class specimen_Q2{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter array size");
        int n=sc.nextInt();
        int pos,data[]=new int[n];
        System.out.println("Enter elements");
        for(int i=0;i<data.length;i++){
            data[i]=sc.nextInt();
        }
        System.out.println("Enter number to be search");
        int search=sc.nextInt();
        for(int i=0;i<data.length;i++){
            if(data[i]==search){
                pos=i;
                System.out.println("The elements found is:"+data[i]+" At position "+(pos+1));
                System.exit(0);
            }
        }
        System.out.println("No such element");
    }
}