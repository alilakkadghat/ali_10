import java.util.*;
class ICSE_Q2
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        int a[] ={2,5,7,10,15,20,29,30,46,50}; 
        int fv=0, lv = a.length-1, m;
        System.out.println(" Enter a roll no. to search");
        int n = sc.nextInt();  // 18 
        while(fv<=lv)
        {
            m=(fv+lv)/2;
            if(n==a[m])
            {
                int pos=m;
                System.out.println(a[m]+"at position  "+(pos+1));
                System.exit(0);
            }
            if(n>a[m])
                fv=m+1;
            if(n<a[m])
                lv=m-1;
        }
            System.out.println("roll no does not exist");
    }
}