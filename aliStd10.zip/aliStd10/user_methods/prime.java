/*
 * Design a class named factorial as per the following specifications
 * class :PRIME
 * Data members/Instance variables
 * int n: to store number entered
 * Member methods
 * void accept():accept the number entered
 * void calc_print():prints wheather number entered is a prime no or not
 * */
package user_methods;
import java.util.*;
class prime
{
    public static int n;
    private static void accept()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter an Integer number:");
        n=sc.nextInt();
    }

    public static void calc_print()
    {
        int i,c=0;
        accept();
         for(i=1;i<=n;i++)
         {
             if(n%i==0)
            c=c+1;
            }
            if(c==2)
             System.out.println(n+" is prime no");
             else
              System.out.println(n+" is not a prime no");
    }
}
