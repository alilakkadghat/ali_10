package user_methods;

import java.util.*;
class parameter_c
{ 
    public static int x,y,z,p;// declaration of global scope variables
    static Scanner sc = new Scanner(System.in);
    public parameter_c(int a, int b) // parameterised constructor
    {
        x=a; // copying values of parameter to global scope varibles
        y=b;//if it was y=y we have to put keyword this.y=
        z=p=0;
    }

    public static  void main()
    {
        parameter_c obj = new parameter_c(12,25);  // creating an object of this class
        //obj.input();
        obj.sum();
        obj.product();
        obj.display();
    }

    public static void sum()
    {
        System.out.println("You are in sum function");
        z = x+y;
    }

    public static  void input()
    {
        System.out.println("You are in Input function");

        System.out.println(" Enter an Integer number");
        x = sc.nextInt(); 
        System.out.println(" Enter another Integer number");
        y = sc.nextInt(); 
    }

    public static void display()
    { 
        System.out.println("You are in print function");
        System.out.println(" x = "+x);
        System.out.println(" y = "+y);
        System.out.println(" sum = "+z);
        System.out.println(" product = "+p);
    }

    public static void product()
    {
        System.out.println("You are in product function");
        p = x*y;
    }    
}