package user_methods;
/*
Define a class named ParkingLot with the following description :
Instance variables/data members:
int vno — To store the vehicle number
int hours — To store the number of hours the vehicle is parked in the parking lot
double bill — Tb store the bill amount
Member methods:
void input( ) — To input and store the vno and hours.
void calculate( ) — To compute the parking charge at the rate of Rs.3 for the first hours ,
 and Rs. 1.50 for each additional hour.
void display ( ) — To display the detail
Write a main method to create an object of the class and call the above methods.
*/
import java.util.*;
class ICSE_2015Q4
{
    int vno,hours;
    double bill;
    void input()
    {
        Scanner ob=new Scanner(System.in);
        System.out.println("enter vehicle number\nno.of hours parked in the parking lot");
        vno=ob.nextInt();
        hours=ob.nextInt();
    }
    void calculate()
    {
        if(hours<=1)
            bill=hours*3;
        else 
            bill=1*3+(hours-1)*1.50;
    }
    void display()
    {
        System.out.println("vehicle number:"+ vno);
        System.out.println("no.of hours parked in the parking lot:"+ hours);
        System.out.println("Parking charge to be paid= RS"+bill);
    }

    public static void main()
    {
       
        ICSE_2015Q4 obj= new ICSE_2015Q4();
        obj.input();
        obj.calculate();
        obj.display();
    }
}
