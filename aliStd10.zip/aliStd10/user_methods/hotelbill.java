
/*
 * Design a class named HotelBill as per the following specifications
 * class :Hotelbill
 * Data members/Instance variables
 * int n:to store number of days stayed in the hotel
 * int bill:to store the bill amount 
 * long mob:to store mobile number
 * String name:to store customers name
 * Member methods
 * void accept():accept customers name along with the mobile number
 * the number of days stayed in the hotel.
 * void calculate ():clculate the bill amount as per the following table

 * No.of days    charges per day
 * first 5 days  2000
 * next 5 days   1500
 * next 7 days   1000
 * excess days   750
 * 
 * void display:display customers name along with mobile number and bill amount as per the format specified
 * NAME   MOBILE NO.    BILL AMOUNT
 * XXXX   XXXXXX         XXXXXX
 * additional 12.5% tax gets addd to the bill amount
 * void main():invokes other methods
 * */
package user_methods;
import java.util.*;
class hotelbill
{
    public static int n,bill;
    public static long mob;
    public static String name;
    private static void accept()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your name:\nEnter the  number of days stayed:\nenter your mobile number");
        name=sc.nextLine();
        n=sc.nextInt();
        mob=sc.nextLong();
    }

    private static void calculate()
    {
        //accept();
        if(n>=1 && n<=5)
        bill=2000*n;
        else if(n>5 && n<=10)
        bill=2000*5+(n-5)*1500;
        else if(n>10 && n<=17)
        bill=2000*5+1500*5+(n-10)*1000;
        else
        bill=2000*5+1500*5+1000*7+(n-17)*750;
    }
    private static void display()
    {
        //calculate();
        double tax;
        int tot;
        tax=0.125*bill;
        tot=(int)tax+bill;
        System.out.println("NAME:\tMOBILE NUMBER:\tBILL AMOUNT ");
        System.out.println(name+"\t"+mob+"\t"+tot);
    }
    public static void main()
    {
       accept();
       calculate();
       display();
}
}
