package user_methods;

class ICSE_2016Q7
{
    public static void SumSeries(int n,double x)
    {
        double S=0;
        for(int i=1;i<=n;i++)
        {
            if(i%2==1)
                S=S+(x/i);
            else
                S=S-(x/i);
        }
        System.out.println(S);
    }

    public static void SumSeries()
    {
        int sum = 0;
        for (int i = 1; i<=20; i++)
        {
            int p=1;
            for(int x = 1; x<=5; x++) 
            {
                p = p * x; 
            }
            sum = sum + p;  
        }
        System.out.println(sum);
    }

    public static void main()
    {
        SumSeries(5,5.2);
        SumSeries();
    }
}
