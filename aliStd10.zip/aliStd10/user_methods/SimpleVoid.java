package user_methods;

import java.util.*;
class SimpleVoid
{
public static void sum(int a, int b)// function prototype
{
int x = a + b; 
System.out.println("sum = "+x);
}

public static void test()// function prototype
{
System.out.println("Hi guys! Thanks for calling me!!! ");
}


public static void main()
{    
    for (int i = 1; i<=2; i++)
    {
    test();
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter an integer");
    int x = sc.nextInt(); // 15
    System.out.println("Enter another integer");
    int y = sc.nextInt(); // 20
    product(x,y); // product(15,20)    
    sum(x,y);  // sum(15,20)
    test2();
    }
}

public static void test2()// function prototype
{
System.out.println("Hi guys! Thanks for calling me again!!! ");
}

public static void product(int a, int b)
{
int x = a * b; 
System.out.println("Product = "+x);
}
}
