package user_methods;
/*
Design a class named CALL_BY_REFERENCE as per following
 specifications
 DATA MEMBERS
 int a,b        :   to store 2 numbers
 MEMBER METHODS
 void accept()      :   accepts the numbers
 void calculate(CALL_BY_REFERENCE)  :   calculates and prints the 
                 sum of the parameters passed*/
import java.util.*;
class CALL_BY_REFERENCE

{
    int a,b;
    public  void accept()
    {
        Scanner ob=new Scanner(System.in);
        CALL_BY_REFERENCE obj1=new CALL_BY_REFERENCE();
        System.out.println("enter 2 numbers");
        obj1.a=ob.nextInt();
        obj1.b=ob.nextInt();
        calculate(obj1);//calling the method by passing object of the class
    }
    public  void calculate(CALL_BY_REFERENCE obj2)
    {
        int s=obj2.a+obj2.b;
        System.out.println("Numbers entered are"+obj2.a+","+obj2.b);
        System.out.println("sum is:"+s);
    }
}
