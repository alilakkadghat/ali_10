package user_methods;

//package user_methods;

/*Design a class name ShowRoom with the following description:
 
Instance variables / Data members:
String name - To store the name of the customer
long mobno - To store the mobile number of the 
                         customer
double cost - To store the cost of the items
                        purchased
double dis - To store the discount amount
double amount - To store the amount to be
                               paid after discount

Member methods:

void input( ) - To input customer name, 
                         mobile number, cost
void calculate( ) - To calculate discount on
                              the cost of purchased items,
                          based on following criteria
                    Cost               Discount
                    <= 10000              5%   
                    >10000 and <=20000    10%
                    >20000 and <=35000    15%
                    More than 35000       20%
void display( ) - To display customer name , 
                  mobile number , amount to be
                  paid after discount.
Write a main method to create an object of the
class and call the above member methods

*/
import java.util.*;
class ShowRoom//Icse2019_Q4
{
    String name;
    long mobno;
    double cost ,dis,amount;
    ShowRoom(){
        String name="ALi";
    long mobno=0L;
    double cost=500.0,dis=0.0,amount=0.0;
    }
    void input()
    {
        Scanner ob=new Scanner(System.in);
        System.out.println("enter customers name, mobile number, cost of item purchase");
        name=ob.nextLine();
        mobno=ob.nextLong();
        cost=ob.nextDouble();
    }
    void calculate()
    {
        if(cost<=10000)
            dis=0.05*cost;
        else if(cost>10000 && cost<=20000)
            dis=0.10*cost;
        else if(cost>20000 && cost<=35000)
            dis=0.15*cost;
        else if(cost>35000)
            dis=0.20*cost;
    }
    void display()
    {
        System.out.println("Customer's name :"+name);
        System.out.println("Mobile number :"+mobno);
        amount=cost-dis;
        System.out.println("Amount to be paid after discount:"+amount);
    }

    public static void main()
    {
       
        ShowRoom obj= new ShowRoom();
        obj.input();
        obj.calculate();
        obj.display();
    }
}
