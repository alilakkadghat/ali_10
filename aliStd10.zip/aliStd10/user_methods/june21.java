package user_methods;
/*
Question 3
Design a class to overload a function Sum( ) as follows:
(i) int Sum(int A, int B): with two integer arguments (A and B) calculate
                                    return sum of all the even 
                    numbers in the range of A and B.        
                        Sample input: A=4 and B=16
                 Sample output: 
       if A=4 and B=16
        sum = 4 + 6 + 8 + 10 + 12 + 14 + 16

(ii) double Sum( double N ) :    with one double arguments(N) 
                               calculate and return the product 
             of the following series:
               sum = 1.0 x 1.2 x 1.4 x …………. x N
 
(iii) int Sum(int N)  :    with one integer argument (N) 
                          calculate and return sum of only
                  odd digits of the number N.
                Sample input : N=43961
               Sample output : sum = 3 + 9 + 1 = 13

Write the main method to create an object and invoke the above methods
*/
class june21
{
    int Sum(int A, int B)
    {
        int i,sum=0;
        for(i=A;i<=B;i=i++)
        {
            if((i%2)==0)
                sum=sum+i;
        }
        return sum;
    }
    double Sum(double N)
    {
        double i,sum=1.0;
        for(i=1.0;i<=N;i=i+0.2)
        {
            sum=sum*i;
        }
        return sum;
    }
    int Sum(int N)
    {
        int dig, sum=0,n1=N;
        while(n1!=0)
        {
            dig=n1%10;
            n1=n1/10;
            if((dig%2)==1)
                sum=sum+dig;
        }
        return sum;
    }
    public static void main()
    {
        june21 obj=new june21();
        int ans1=obj.Sum(4,16);
        double ans2=obj.Sum(10.0);
        int ans3=obj.Sum(12345);
        System.out.println(ans1);
        System.out.println(ans2);
        System.out.println(ans3);
    }
}
