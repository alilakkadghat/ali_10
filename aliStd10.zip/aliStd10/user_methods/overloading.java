package user_methods;

class overloading
{       // data type      Number of arguments
    public static void sum(int x, int y)  // Function number 1
    {
        System.out.println("Sum of two integers 111 "+(x+y));
    }

    public static void sum(int a, int b, int c)  // Function number 1
    {
        System.out.println("Sum of two integers 333 "+(a+b+c));
    }

    public static void sum(double a, double b) // Function number 3
    {
        System.out.println("Sum of two decimals 222 "+(a+b));
    }

    public static void main()  
    {       
        sum(2,3.0);      // 444 will call function 4  only
        sum(5,10);      // 111 will call function 1  only
        sum(2,3,4);     // 333 will call function 3  only
        sum(4.2,3.2);    // 222 will call function 2  only
        sum(5.0,4);      // 555 will call function 5  only
    }

    public static void sum(double a, int b) // Function number 3
    {
        System.out.println("Sum of two decimals 555 "+(a+b));
    }

    public static void sum(int a, double b) // Function number 3
    {
        System.out.println("Sum of two decimals 444 "+(a+b));
    }

}
