package user_methods;

class ReturnType
{
public static int sum(int a,int b)
{
int z = a+b;
return z;
}
 public static void main()
{
//System.out.println(sum(2,3));  // 5
int x = sum(20,30);  // 50
int y = product(20,30);
System.out.println(formula(x,y));
}
public static double formula(double a, double b)
{
    double c = b/a;
    return c;
}
public static int product(int a, int b)
{
    int c = a*b;
    return c;
}
}
