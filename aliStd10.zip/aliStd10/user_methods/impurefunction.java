package user_methods;
/*Design a class named impurefunction1 as per following specifications
Member methods
void accept()                    :   accepts 2 numbers
void calculate(int , int)   :   displays the sum of the parameters
                  passed after incrementing their value 
                  also displays the parameters value
 */
import java.util.*;
class impurefunction
{
    public static void accept()
    {
        Scanner ob = new Scanner(System.in);
        int a,b;
        System.out.println("enter 2 numbers");
        a=ob.nextInt();
        b=ob.nextInt();
        calculate(a,b);// CALL BY VALUE
    }
    public static void calculate(int a1,int b1)
    {
        
        int s=(a1++)+(b1++);
        System.out.println("The first number is :"+a1);
        System.out.println("The second number is:"+b1);
        System.out.println("sum is :"+s);
    }
}
