/*
 * Design a class named factorial as per the following specifications
 * class :FACTORIAL
 * Data members/Instance variables
 * int n:l to store number entered
 * Member methods
 * void accept():accept the number entered
 * void calc_print():prints the factorial of the number entered
 * Eg let the number be 5
 * Answer:5!=120
 * ! is the sign for factorial
 * 5!=1*2*3*4*5=120
 * */
package user_methods;
import java.util.*;
class fac
{
    public static int n;
    private static void accept()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter an Integer number:");
        n=sc.nextInt();
    }

    public static void calc_print()
    {
        int x=1;
        accept();
        for(int i=1;i<=n;i++)
        {
            x=x*i;
        }
        System.out.println("The factorial of the number "+n+"! is: "+ x);
    }
   
}
