package user_methods.exercise_function;

import java.util.*;
class Pf
{

    int calc (int n)
    {
        int s=0;
        for(int i=1;i<=n;i++)
      {
        s=s+i;
     }
        return s;
    }

    int calc()
    {
        int x=1;
        for(int i=1;i<=5;i++)
      {
       x=x*i;
     }
        return x;
    }

    public static void main()
    {
        Pf obj=new Pf();
        int x=obj.calc(10);
        int z=obj.calc();
        System.out.println("Sum of series=  "+x);
        System.out.println("value of 5 factorial=  "+z);
    }
}