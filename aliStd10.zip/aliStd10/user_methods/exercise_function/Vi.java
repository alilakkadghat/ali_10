package user_methods.exercise_function;

import java.util.*;
class Vi
{

    private static void perfect(int i)
    {
        int c=0,j;
        for(j=1;j<i;j++)
        {
            if(i%j==0)
                c=c+j;
        }
        if(c==i)
            System.out.println(i+" is perfect no");
    
    }

    public static void main()
    {
        int i;
        for(i=1;i<=10000;i++)
        {
            perfect(i);
        }
        
    }
}