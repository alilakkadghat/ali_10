package user_methods.exercise_function;

import java.util.*;
class Vg
{

    private static void amount(String z,int n,double p)
    {
        double r=0;
        if(n>=0 && n<1)
            r=9;
        else if(n>=1 && n<=3)
            r=9.25;
        else if(n>3 && n<=5)
            r=9.5;
        else
            r=9.75;
        double A=p*Math.pow(1+(r/100),n);
        System.out.println("Name:"+z);
        System.out.println("no.of years:"+n);
        System.out.println("Rate of interest:"+r);
        System.out.println("bill amount:"+A);
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your name");
        String z=sc.nextLine();
        System.out.println("Enter number of years");
        int  n=sc.nextInt();
        System.out.println("Enter principal amount");
        double p=sc.nextDouble();
        amount(z,n,p);
    }
}