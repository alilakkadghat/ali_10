package user_methods.exercise_function;

import java.util.*;
class Vm
{

    private static void automorphic(int i)
    {
        int d,s=1,b=i,sq=i*i;
        while(i!=0){
            d=i%10;
            i=i/10;
            s=s*10;
        }
        int auto=sq%s;
        if(b==auto)
            System.out.println(b+" is automorphic no");
    }

    public static void main()
    {
        int i;
        for(i=1;i<=1000;i++)
        {
            automorphic(i);
        }

    }
}