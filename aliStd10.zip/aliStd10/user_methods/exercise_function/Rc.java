package user_methods.exercise_function;

import java.util.*;
class Rc extends Ve
{

    private static double area(double h,double b)
    {
        double a=0.5*b*h;
        return a;
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter height of the triangle");
        double h=sc.nextDouble();
        System.out.println("Enter base of the triangle");
        double b=sc.nextDouble();
        System.out.println("Area of a triangle= "+area(h,b));
    }
}