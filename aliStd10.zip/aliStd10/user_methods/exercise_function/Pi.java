package user_methods.exercise_function;

import java.util.*;
class Pi
{

    void gravity (int h)
    {
        double g=32.17*Math.pow((4390/(4390+h)),2);
        System.out.println(h+"\t"+g);
    }

    void gravity(double h)
    {
        double g=32.17*Math.pow((1.0/(h+4390)),2);
        System.out.println(h+"\t"+g);
    }

    public static void main()
    {
        System.out.println("Height"+"\t"+"Gravity");
        Pi obj=new Pi();
        for(int h=-4;h<=10;h++)
        {
            if(h>3)
                obj.gravity(h);
            else
            {
                double N=h;
                obj.gravity(N);
            }

        }
    }
}