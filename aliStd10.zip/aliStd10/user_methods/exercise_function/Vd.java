package user_methods.exercise_function;

import java.util.*;
class Vd
{

    private static void area(double s)
    {
        double a=s*s;
        System.out.println("Area of square ="+a);
    }

    private static void perimeter(double s)
    {
        double a=4*s;
        System.out.println("perimeter of square ="+a);
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter side of a square");
        double s=sc.nextDouble();
        area(s);
        perimeter(s);
    }
}