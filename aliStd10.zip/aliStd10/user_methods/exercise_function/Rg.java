package user_methods.exercise_function;
import java.util.*;
class Rg extends Vj
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int p=sc.nextInt();
        int x=palindrome(p);
        if(x==1)
        System.out.println(p+" Is a palindrome no");
        else
         System.out.println(p+" Is not a palindrome no");
    }
    private static int palindrome(int p)
    {
        int d,rev=0,b=p;
        while(p!=0)
        {
         d=p%10;
         p=p/10;
         rev=(rev*10)+d;
        }
        if(rev==b)
        return 1;
        else
        return 0;
    }
}