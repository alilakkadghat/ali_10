package user_methods.exercise_function;
import java.util.*;
class BEST
{
    int n;
    double tax,bill;
    long tel; double f;
    String name;
    BEST(){
        n=0;
        tax=bill=f=0.0d;
        tel=0L;
        name="";
    }

    void accept()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your name:\nEnter the  number of calls:\nenter your telephone number");
        name=sc.nextLine();
        n=sc.nextInt();
        tel=sc.nextLong();
    }

    void billing()
    {

        if(n>=0 && n<=100)
            bill=0;
        else if(n>100 && n<=300)
            bill=100*0+(n-100)*0.80;
        else if(n>300 && n<=500)
            bill=100*0+200*0.80+(n-300)*1.25;
        else
            bill=100*0+200*0.80+200*1.25+(n-500)*2.5;
        tax = 0.12*bill;
        f = bill + tax;

    }

    void display()
    {
     
        System.out.println("NAME:\ttelephone NUMBER:\t No of calls:\tBILL AMOUNT ");
        System.out.println(name+"\t"+tel+"\t"+n+"\t"+f);
    }

    public static void main()
    {
        BEST obj=new BEST();
        obj.accept();
        obj.billing();
        obj.display();
    }
}
