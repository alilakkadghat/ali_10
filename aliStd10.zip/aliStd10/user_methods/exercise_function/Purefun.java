package user_methods.exercise_function;
class Purefun
{
String name;
char grade;
int rollno,total;
public char gradDiv(int tmarks){
    if(tmarks>=750)
    grade='A';
    else if(tmarks>=600 && tmarks<750)
    grade='B';
    else if(tmarks>=400 && tmarks<600)
    grade='C';
    else if(tmarks<400)
    grade='F';
    return grade;
}
public void display(int roln,char grad){
    System.out.println("Roll No."+roln+"Division"+grad);
}
public static void main()
{
Purefun std1=new Purefun();
std1.name="Akshay";std1.rollno=111;std1.total=590;
std1.grade=std1.gradDiv(std1.total);
System.out.println("Student Name:"+std1.name);
std1.display(std1.rollno,std1.grade);
}
}