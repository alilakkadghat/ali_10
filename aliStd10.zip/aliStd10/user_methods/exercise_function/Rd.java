package user_methods.exercise_function;

import java.util.*;
class Rd
{
    public static void main()
    {
        Scanner sc =  new Scanner (System.in);
        System.out.println("enter ur  salary ");
        double  s = sc.nextDouble();
        System.out.println("the tax = " + calc(s)); 
    }
    
    private static double calc(double s )
    {
        double tax = 0;
        if (s>0 && s<=170000)
           tax = 0;
        else if (s>170000 && s<=500000)
            tax = s * 0.10;
        else if ( s>500000 && s<=530000)
            tax = 0.20 * s;
        else 
            tax = 0.30*s;
        return tax; 
        }
        
    }
