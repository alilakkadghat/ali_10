package user_methods.exercise_function;

import java.util.*;
class Rb extends Vd
{

    private static double area(double s)
    {
        double a=s*s;
        return a;
    }

    private static double perimeter(double s)
    {
        double a=4*s;
       return a;
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter side of a square");
        double s=sc.nextDouble();
        System.out.println("Area of square= "+area(s));
        System.out.println("perimeter of square= "+perimeter(s));
    }
}