package user_methods.exercise_function;

import java.util.*;
class Pd
{

    void sequence (int n)
    {
      for(int i=1;i<=n;i++)
      {
       if(i%2==0)
        System.out.println(i);
     }
     System.out.println();
    }

    void sequence(int a,int b)
    {
        for(int i=a;i<=b;i++)
      {
        System.out.println(i);
     }
     System.out.println();
    }
    
    void sequence()
    {
       for(int i=1;i<=25;i++)
      {
       if(i%2==1)
        System.out.println(i);
     }
    }

    public static void main()
    {
        Pd obj=new Pd();
        obj.sequence(50);
        obj.sequence(10,30);
        obj.sequence();
    }
}