package user_methods.exercise_function;

import java.util.*;
class Va
{

    private static void sum (int x,int y)
    {
        int s=x+y;
        System.out.println("Sum ="+s);
    }

    private static void product(int x,int y)
    {
        int s=x*y;
        System.out.println("product="+s);
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int x=sc.nextInt();
        System.out.println("Enter another number");
        int y=sc.nextInt();
        sum(x,y);
        product(x,y);

    }
}