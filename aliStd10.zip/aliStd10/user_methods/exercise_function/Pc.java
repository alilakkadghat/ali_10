package user_methods.exercise_function;

import java.util.*;
class Pc
{

    double area (double s)
    {
        double a=s*s;
        return a;
    }

    double area(double l,double b)
    {
        double a=l*b;
        return a;
    }

    double area(double b,int h)
    {
        double a=0.5*b*h;
        return a;
    }

    public static void main()
    {
        Pc obj=new Pc();
        double x=obj.area(4.0);
        //double y=obj.area(2.0,3.0);
        double z=obj.area(2.0,6);
        System.out.println("Area of Square=  "+x);
        System.out.println("Area of Rectangle=  "+obj.area(3.0,3.0));
        System.out.println("Area of Square=  "+z);
    }
}