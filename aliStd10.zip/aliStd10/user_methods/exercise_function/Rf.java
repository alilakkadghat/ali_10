package user_methods.exercise_function;

import java.util.*;
class Rf extends Vi
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int  p=sc.nextInt();
        boolean x=perfect(p);
        if(x==true)
            System.out.println(p+" Is a perfect no");
        else
            System.out.println(p+" Is Not a perfect no");
    }

    private static boolean perfect(int p)
    {
        int c=0,i;
        for(i=1;i<p;i++)
        {
            if(p%i==0)
                c=c+i;
        }
        if(c==p)
            return true;
        else
            return false;
    }

}