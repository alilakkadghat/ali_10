package user_methods.exercise_function;

import java.util.*;
class Vl
{

    private static void neon(int n)
    {
        int d,c=0,sq=n*n;
        while(sq!=0){
            d=sq%10;
            sq=sq/10;
            c=c+d;
        }
        if(n==c)
            System.out.println(n+" is neon no");
    }

    public static void main()
    {
        int n;
        for(n=1;n<=1000;n++)
        {
            neon(n);
        }

    }
}