package user_methods.exercise_function;

import java.util.*;
class Pa
{

    void sum (int x,int y)
    {
        int s=x+y;
        System.out.println("Sum of integers ="+s);
    }

    void sum(double x,double y)
    {
        double s=x+y;
        System.out.println("Sum of decimals="+s);
    }

    public static void main()
    {
        Pa obj=new Pa();
        obj.sum(2,5);
        obj.sum(2.0,3.0);
        /*Scanner sc=new Scanner(System.in);
        System.out.println("Enter two real number");
        int x=sc.nextInt();
        int y=sc.nextInt();
        System.out.println("Enter two decimal number");
        double a=sc.nextDouble();
        double b=sc.nextDouble();
        Pa ob=new Pa();
        ob.sum(x,y);
        ob.sum(a,b);*/
    }
}