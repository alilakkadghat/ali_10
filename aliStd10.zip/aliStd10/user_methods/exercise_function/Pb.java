package user_methods.exercise_function;

import java.util.*;
class Pb
{

    void calculate (int x,int y)
    {
        int s=x+y;
        System.out.println("sum of no ="+s);
    }

    void calculate(double x,int y)
    {
        double s=x*y;
        System.out.println("product of no="+s);
    }
    
    void calculate(int x,double y)
    {
        double s=x-y;
        System.out.println("difference between no="+s);
    }
    
    void calculate(double x,double y)
    {
        double s=x/y;
        System.out.println("quotient of no="+s);
    }

    public static void main()
    {
        Pb obj=new Pb();
        obj.calculate(2,5);
        obj.calculate(2.0,5);
        obj.calculate(2,5.0);
        obj.calculate(2.0,5.0);
    }
}