package user_methods.exercise_function;

import java.util.*;
class Re extends Vh
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int  p=sc.nextInt();
        boolean x=prime(p);
        if(x==true)
        System.out.println(p+" Is a prime no");
        else
        System.out.println(p+" Is Not a prime no");
    }
    
    private static boolean prime(int p)
    {
        int c=0,i;
        for(i=1;i<=p;i++)
        {
            if(p%i==0)
                c=c+1;
        }
        if(c==2)
            return true;
        else
            return false;
    }

}