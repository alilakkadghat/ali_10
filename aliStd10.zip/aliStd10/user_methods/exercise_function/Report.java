package user_methods.exercise_function;

import java.util.*;
class Report
{
    String name,div;
    int rn,std;
    double math,bio,phy,chem,comp,hindi,tot,avg;
    Report()
    {
        name="";div="";
        rn=std=0;
        math=bio=phy=chem=comp=hindi=0.0d;
    }

    void input()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter  name ");
         name =sc.nextLine();
        System.out.println("Enter roll number");
         rn=sc.nextInt();
        System.out.println("Enter std");
         std=sc.nextInt();
          System.out.println("Enter division");
         div=sc.next();
        System.out.println("Enter marks in maths,bio,phy,chem,comp,hindi");
         math=sc.nextInt();
          bio=sc.nextInt();
           phy=sc.nextInt();
            chem=sc.nextInt();
             comp=sc.nextInt();
              hindi=sc.nextInt();
    }
    

    void total()
    {
        tot=math+bio+phy+chem+comp+hindi;
    }

    void average()
    {
       avg=tot/6;
    }

    void display(){
        System.out.println("Report Card:");
        System.out.println("Name :  "+name);  
        System.out.println("Roll number:  "+rn);
        System.out.println("std:  "+std);
        System.out.println("div:  "+div);
        System.out.println("math :  "+math);  
        System.out.println("bio:  "+bio);
        System.out.println("phy:  "+phy);
        System.out.println("chem:  "+chem);
        System.out.println("comp:  "+comp);
        System.out.println("hindi:  "+hindi);
        System.out.println("total marks:  "+tot);
        System.out.println("average marks:  "+avg);
    }

    public static void main()
    {
        Report obj=new Report();
        obj.input();
        obj.total();
        obj.average(); 
        obj.display();

    }
}