package user_methods.exercise_function;

import java.util.*;
class Ve
{

    private static void area(double h,double b)
    {
        double a=0.5*b*h;
        System.out.println("Area of triangle ="+a);
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter height of the triangle");
        double h=sc.nextDouble();
        System.out.println("Enter base of the triangle");
        double b=sc.nextDouble();
        area(h,b);
    }
}