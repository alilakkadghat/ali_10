package user_methods.exercise_function;

import java.util.*;
class Vk
{

    private static void armstrong(int p)
    {
        int b=p,i,d,s=0;
        while(p!=0){
            d=p%10;
            p=p/10;
            s=s+(d*d*d);
        }
        if(b==s)
            System.out.println(b+" is armstrong no");
        else
            System.out.println(b+" not a armstrong no");
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int  p=sc.nextInt();
        armstrong(p);
    }
}