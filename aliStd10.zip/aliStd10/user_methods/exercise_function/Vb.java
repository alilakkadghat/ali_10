package user_methods.exercise_function;

import java.util.*;
class Vb
{

    private static void series (int n)
    {
        for(int i=1;i<=n;i++){
         System.out.println(i);
        }
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int n=sc.nextInt();
        series(n);

    }
}