package user_methods.exercise_function;

import java.util.*;
class Vf
{

    private static void billing(String z,int n)
    {
        double amt=0;
        if(n>=0 && n<=100)
            amt=1*n;
        else if(n>100 && n<=300)
            amt=1*100+(n-100)*1.5;
        else if(n>300 && n<=500)
            amt=1*100+1.5*200+(n-300)*2;
        else
            amt=1*100+1.5*200+2*200+(n-500)*2.5;
        System.out.println("Name:"+z);
        System.out.println("no.of calls:"+n);
        System.out.println("bill amount:"+amt);
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your name");
        String z=sc.nextLine();
        System.out.println("Enter number of calls made");
        int  n=sc.nextInt();
        billing(z,n);
        //Vf obj=new Vf();
        //obj.billing(z,n);
    }
}