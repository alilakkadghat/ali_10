package user_methods.exercise_function;

import java.util.*;
class Employee
{
    String name;
    int ecode,bs;
    double all,gs,tax,hra,ns;
    Employee()
    {
        name="";
        bs=ecode=0;
        all=gs=tax=hra=ns=0.0d;
    }

    void accept()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Employee name ");
         name =sc.nextLine();
        System.out.println("Enter Employee code number");
         ecode=sc.nextInt();
        System.out.println("Enter basic salary");
         bs=sc.nextInt();
    }

    void allow()
    {
        all=0.55*bs;
    }

    void house()
    {
        hra=0.33*bs;
    }

    void gross()
    {
        gs=bs+hra+all;
    }

    void incometax()
    {
        tax=0.12*gs;
    }

    void net()
    {
        ns=gs-tax;
    }

    void display(){
        System.out.println("SALARY SLIP:");
        System.out.println("Name of the employee:  "+name);  
        System.out.println("Employee code number:  "+ecode);
        System.out.println("basic salary:  "+bs);
        System.out.println("tax:  "+tax);
        System.out.println("net salary:  "+ns);

    }

    public static void main()
    {
        Employee obj=new Employee();
        obj.accept();
        obj.allow();
        obj.house(); 
        obj.gross();
        obj.incometax();
        obj.net();
        obj.display();

    }
}