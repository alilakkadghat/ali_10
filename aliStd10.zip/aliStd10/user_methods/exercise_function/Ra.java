package user_methods.exercise_function;

import java.util.*;
class Ra extends Vc
{

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter radius of the circle");
        double r=sc.nextDouble();
        System.out.println("Area of Circle= "+area(r));

    }
      private static double area(double r)
    {
        double a=3.142*Math.pow(r,2);
         return a;
    }
}