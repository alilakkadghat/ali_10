package user_methods.exercise_function;

import java.util.*;
class Vh
{

    private static void prime(int p)
    {
        int c=0,i;
        for(i=1;i<=p;i++)
        {
            if(p%i==0)
                c=c+1;
        }
        if(c==2)
            System.out.println(p+" is prime no");
        else
            System.out.println(p+" not a prime no");
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int  p=sc.nextInt();
        prime(p);
    }
}