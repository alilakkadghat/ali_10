package user_methods.exercise_function;

import java.util.*;
class Ph
{

    void volume (double s)
    {
        double a=s*s*s;
        System.out.println("volume of cube =  "+a);
    }

    void volume(double r,double p)
    {
        double a=(4/3)*3.14*r*r*r;
        System.out.println("volume of sphere =  "+a);
    }

    void volume(double l,double b,double h)
    {
        double a=l*b*h;
        System.out.println("volume of cuboid =  "+a);
    }

    public static void main()
    {
        Ph obj=new Ph();
        obj.volume(4.0);
        obj.volume(2.0,3.0);
        obj.volume(2.0,6.0,8.0);

    }
}