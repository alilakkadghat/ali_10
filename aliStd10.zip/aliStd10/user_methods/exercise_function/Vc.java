package user_methods.exercise_function;

import java.util.*;
class Vc
{

    private static void area(double r)
    {
        double a=3.142*Math.pow(r,2);
         System.out.println("Area of circle ="+a);
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter radius of the circle");
        double r=sc.nextDouble();
        area(r);

    }
}