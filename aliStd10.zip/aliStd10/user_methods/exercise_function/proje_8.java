package user_methods.exercise_function;
import java.util.*;
class proje_8
{
    public static void main()
    {
        int roll[]={11,13,14,16,18,20,22,23,25};
        int mark[]={75,44,55,75,77,88,99,100,54};
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a roll number");
        int n = sc.nextInt();
        for (int i = 0; i < roll.length; i++) 
        {
            if(roll[i] == n){
                System.out.println("roll no: "+roll[i]+"-"+"Marks obtained: "+mark[i]);
                System.exit(0);
            }
        }
        System.out.println("not found");
    }
}
