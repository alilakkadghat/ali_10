package user_methods.exercise_function;

import java.util.*;
class Library
{
    public static int b_no,r_days;
    public static long  ph_no;
    public static double f_amt;
    public static String s_name;
    Library()
    {
        b_no = 0000;
        ph_no = 123456789L;
        r_days =  0;
        f_amt = 0.0d;
        s_name = "Lucifer";
    }

    public static void main()
    {
        Library obj = new Library();
        obj.Accept();
        obj.Fine();
        System.out.println("Book No. \t Phone No \t Name \t\t No.of days \t Fine");
        obj.Display();
    }

    public static void Accept()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name of student");
        s_name = sc.nextLine();
        System.out.println(" Enter book number ");
        b_no = sc.nextInt();
        System.out.println("Enter phone number");
        ph_no = sc.nextLong();
        System.out.println("Enter number of days that the book returned late");
        r_days = sc.nextInt();
    }

    public static void Fine()
    {
        if (r_days<=5)
            f_amt = r_days*1.50;
        else if(r_days>5 && r_days<=10)
            f_amt = 5*1.50+(r_days-5)*1.75;
        else
            f_amt=5*1.50+5*1.75+(r_days-10)*2;
    }

    public static void Display()
    {
        System.out.println(b_no+"\t\t"+ph_no+"\t\t"+s_name+"\t\t"+r_days+"\t\t"+
            f_amt);
    }

}