package user_methods.exercise_function;

import java.util.*;
class Vj
{

    private static void palindrome(int i)
    {
        int j,d,rev=0,b=i;
        while(i>0){
            d=i%10;
            i=i/10;
            rev=(rev*10)+d;
        }
        if(b==rev)
            System.out.println(b+" is palindrome no");
    }

    public static void main()
    {
        int i;
        for(i=1;i<=1000;i++)
        {
            palindrome(i);
        }

    }
}