package user_methods.exercise_function;

import java.util.*;
class Big_Bazar
{
    String name,add;
    double purchase,discount,amt,tax,bill;
    Big_Bazar()
    {
        name="";
        add="";
        purchase=amt=tax=bill=0.0d;
    }

    void accept()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Your name ");
         name =sc.nextLine();
        System.out.println("Enter Your address");
         add=sc.nextLine();
        System.out.println("Enter purchase amount");
         purchase=sc.nextDouble();
    }

    void discount()
    {
       if(purchase>=1000)
       discount=0.15*purchase;
    }

    void amount()
    {
        amt=purchase-discount;
    }

    void tax()
    {
        tax=0.12*amt;
    }

    void bill()
    {
        bill=amt+tax;
    }

    void output(){
        System.out.println("BILL:");
        System.out.println("Name of the customer:  "+name);  
        System.out.println("Address of the customer:  "+add);
        System.out.println("Purchase amount:  "+purchase);
        System.out.println("Discount:  "+discount);
        System.out.println("Discounted prize:  "+amt);
        System.out.println("tax:  "+tax);
        System.out.println("net bill:  "+bill);

    }

    public static void main()
    {
        Big_Bazar obj=new Big_Bazar();
        obj.accept();
        obj.discount();
        obj.amount(); 
        obj.tax();
        obj.bill();
        obj.output();

    }
}