package user_methods.exercise_function;

import java.util.*;
class Proj
{

    public static void sum (int a,int b)
    {
        int s=a+b;
        System.out.println("Sum of integers ="+s);
    }

    public static void sum(double a,double b)
    {
        double s=a+b;
        System.out.println("Sum of decimals="+s);
    }

    public static void main()
    {
        sum(5,10);
        sum(5.5,1.5);
    }
}