package user_methods.exercise_function;
import java.util.*;
class Bank
{
    double rate,P,CI,time;
    Bank(double r,int t){
        rate=r;
        time=t;
        CI=0.0d;
    }

    void accept()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Principal amount");
        P=sc.nextDouble();
    }

    void compoundInterest()
    {
        CI=P*(Math.pow(1+(rate/100),time));
    }

    void display()
    {

        System.out.println("INTERST AMOUNT: ");
        System.out.println(CI);
    }

    public static void main()
    {
        Bank obj=new Bank(0.15,4);
        obj.accept();
        obj.compoundInterest();
        obj.display();
    }
}
