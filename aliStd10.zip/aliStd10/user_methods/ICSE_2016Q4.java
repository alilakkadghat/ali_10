package user_methods;
/*Design a class name ShowRoom with the following description:
 
Define a class named BookFair with the following description: [15]
Instance variables/Data members :
String Bname — stores the name of the book
double price — stores the price of the book Member methods :
(i) BookFair() — Default constructor to initialize data members
(ii) void Input() — To input and store the name and the price of the book.
(iii) void calculate() — To calculate the price after discount. Discount is calculated based on the following criteria.

Price	                                                                  Discount
Less than or equal to Rs. 1000	                                         2% of price
More than Rs. 1000 and less than or equal to Rs. 3000	                 10% of price
More than % 3000	                                                 15% of price
(iv) void display() — To display the name and price of the book after discount. 
Write a main method to create an object of the class and call the above member methods.

*/
import java.util.*;
class ICSE_2016Q4
{
    String Bname;
    double price,dis,amt;
    ICSE_2016Q4(){
    String Bname="";
    double price=0.0;
    }
    void input()
    {
        Scanner ob=new Scanner(System.in);
        System.out.println("enter Book name, Price of the Book");
        Bname=ob.nextLine();
        price=ob.nextDouble();
    }
    void calculate()
    {
        if(price<=1000)
            dis=2.0/100*(price);
        else if(price>1000 && price<=3000)
            dis=10.0/100*(price);
        else 
            dis=15.0/100*(price);
    }
    void display()
    {
        System.out.println("Book's name :"+Bname);
        amt=price-dis;
        System.out.println("Amount to be paid after discount:"+amt);
    }

    public static void main()
    {
       
        ICSE_2016Q4 obj= new ICSE_2016Q4();
        obj.input();
        obj.calculate();
        obj.display();
    }
}
