package user_methods;
/*
Anshul transport company charges for the parcels of its customers as per the following
specifications given below:
Class name : Atransport
Member variables: String name – to store the name of the customer
int w – to store the weight of the parcel in Kg
int charge – to store the charge of the parcel
Member functions: void accept ( ) – to accept the name of the customer,
weight of the parcel from the user (using
Scanner class)

void calculate ( ) – to calculate the charge as per the weight
of the parcel as per the following
criteria.

Weight in Kg             Charge per Kg
Upto 10 Kgs              Rs.25 per Kg
Next 20 Kgs              Rs.20 per Kg
Above 30 Kgs             Rs.10 per Kg

A surcharge of 5% is charged on the charge.
void print ( ) – to print the name of the customer, weight of the parcel, total charge
inclusive of surcharge in a tabular form in the following format :

Name Weight charge amount
------- --------- ---------------
Define a class with the above-mentioned specifications, create the main method,
create an object and invoke the member methods.
 */
import java.util.*;
import java.util.Date;
class ICSE_2020speciQ4
{
    String name;
    int w;int charge;double tot_charge;
    void accept()
    {
        Scanner ob=new Scanner(System.in);
        System.out.println("Enter name of the customer and weight of the parcel");
        name=ob.nextLine();
        w=ob.nextInt();
    }

    void calculate()
    {
        if(w>=0 && w<=10)
            charge=25*w;
        else if(w>10 && w<=30)
            charge=25*10+(w-10)*20;
        else
            charge = 25*10+20*20+(w-30)*10;
        tot_charge=charge+0.05*charge;
    }

    void print()
    {
        System.out.println("Name of the customer:"+name);
        System.out.println("weight of the parcel:"+w);
        System.out.println("charge amount:"+(int)tot_charge);
    }

    public static void main()
    {
        Date date =new Date();
        System.out.print("the file was Opened at\n");
        System.out.println(date.toString());
        ICSE_2020speciQ4 obj= new ICSE_2020speciQ4();
        obj.accept();
        obj.calculate();
        obj.print();
    }
}
