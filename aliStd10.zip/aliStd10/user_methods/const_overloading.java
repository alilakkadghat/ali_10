package user_methods;


class const_overloading
{
String nm,dob;
int ag;
double ht;
long mob;
const_overloading()
{
nm="xyz";
dob="00.00.0000";
ag=0;
ht=0.0;
mob=0;
}
const_overloading(String nm1,String dob1,long mob1,int ht1,int ag1)
{
nm=nm1;
dob=dob1;
mob=mob1;
ht=ht1;
ag=ag1;
}
public void display()
{
System.out.println("name:"+nm);
System.out.println("date of birth :"+dob);
System.out.println("Mobile number:"+mob);
System.out.println("Height:"+ht);

System.out.println("age :"+ag);
}

public static void main()
{
const_overloading obj1=new const_overloading();
System.out.println("default values are");
obj1.display();

const_overloading obj2=new const_overloading("sonia","25.06.92",12345,5,20);
System.out.println("new values are");
obj2.display();
}
}