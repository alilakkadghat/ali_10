
/* Design a class named PRIMEPalindrome as per the following specifications
 * class :PRIMEPalindrome
 * Data members/Instance variables
 * int n: to store number entered
 * int c:to store the number of factors of the number entered
 * int rev:to store reverse of the number entered
 * Member methods
 * void accept():accept the number entered
 * void calculate():calculates the reverse of the number & 
 * also finds the no of divisors of the number
 * void main():invokes the other methods & invokes prints whether
 * the number entered is a primepalindrome number or not.
 * A palindome number is a number which is a prime number 
 * as well as a palindrome number
 * */
package user_methods;
import java.util.*;
class Primepalindroem
{
    public static int n,c=0,rev=0;
    private static void accept()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number:");
        n=sc.nextInt();
    }

    private static void calculate()
    {
        int i;
        for(i=1;i<=n;i++)
        {
            if(n%i==0)
                c=c+1;
        }
        int n1=n,d;
        while(n1!=0)
        {
            d=n1%10;
            n1=n1/10;
            rev=(rev*10)+d;
        }
    }

    public static void main()
    {
        accept();
        calculate();
        if(c==2 && n==rev)
            System.out.println(n+" is primepalindrome  no");
        else
            System.out.println(n+" is not a primepalindrome no");
        //System.exit(0);
        c=0;rev=0;
    }
}