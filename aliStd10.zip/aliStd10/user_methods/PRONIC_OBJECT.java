package user_methods;

/*Design a class named PRONIC_OBJECT as per following details
class : PRONIC_OBJECT
Data members/Instance variables
int n   :   to store the number user enters
Member methods
void input( )   :   accepts the number
void check( )   :   checks whether the number is a pronic 
number or not.
Pronic number is the number
which is the product 
of two consecutive integers
Examples: 12 = 3 * 4
20 = 4 * 5
42 = 6 * 7
void main()     :   creates object of the class 
and invokes the methods 
accordingly               
 */
import java.util.*;
class PRONIC_OBJECT
{
    public int n;
    public void input()
    {
        Scanner ob=new Scanner(System.in);
        System.out.println("enter a number");
        n=ob.nextInt();
    }

    public void check()
    {
       // boolean b=false;
        for(int i=1;i<n;i++)
        {
            int x=i*(i+1);
            if(n==x)
            {
                System.out.println(n+" is a pronic number");
                System.exit(0);
              //  b=true;
               // break;
            }
        }
       // if(b==true)
         //   System.out.println("no.entered is a pronic number");
        //else
            System.out.println(n+" is not a pronic number");
    }

    public static void main()
    {
        PRONIC_OBJECT obj= new PRONIC_OBJECT();
        obj.input();
        obj.check();
    }
}
