package user_methods;

class ICSE_2014Q7
{

    private static double area(double a,double b, double c)
    {
        double s = (a+b+c)/2;
        double area = Math.sqrt(s*(s-a)*(s-b)*(s-c));
        return area;
    }

    private static double area(int a,int b,int height)
    {
        double area = 0.5 * height * (a+b);
        return area;
    }

    private static double area(double diagonal1,double diagonal2)
    {
        double area = 0.5*(diagonal1*diagonal2);
        return area;
    }

    public static void main()
    {
        System.out.println(area(2.0,3.0,4.0));
        System.out.println(area(2,3,4));
        System.out.println(area(5.0,6.0));
    }
}
