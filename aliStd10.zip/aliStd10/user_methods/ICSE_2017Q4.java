package user_methods;
/*
Define a class ElectricBill with the following specifications : [15]
class : ElectricBill
Instance variables /data member :
String n – to store the name of the customer
int units – to store the number of units consumed
double bill – to store the amount to be paid
Member methods :
void accept ( ) – to accept the name of the customer and number of units consumed
void calculate ( ) – to calculate the bill as per the following tariff :

no.of units                       Rate per unit
First 100	                  Rs 2.0
next 200	                  Rs 3.00
above 300	                  Rs 5.00
A surcharge of 2.5% charged if the number 
of units consumed is above 300 units.
(iv) void print() — To print details as follows:
Name of the customer:____
Number of units consumed____
Bill amount _____
Write a main method to create an 
object of the class and call the above member methods.

 */
import java.util.*;
class ICSE_2017Q4
{
    String n;
    double bill;int units;
    void accept()
    {
        Scanner ob=new Scanner(System.in);
        System.out.println("Enter name of the customer and number of units consumed");
        n=ob.nextLine();
        units=ob.nextInt();
    }

    void calculate()
    {
        if(units>=0 && units<=100)
            bill=2*units;
        else if(units>100 && units<=300)
            bill=2*100+(units-100)*3;
        else{ 
            double amt = 2*100+3*200+(units-300)*5;
            double surcharge = amt*0.025;
            bill = amt + surcharge;
        }
    }

    void print()
    {
        System.out.println("Name of the customer:"+n);
        System.out.println("Number of units consumed:"+units);
        System.out.println("Bill amount:"+bill);
    }

    public static void main()
    {
        ICSE_2017Q4 obj= new ICSE_2017Q4();
        obj.accept();
        obj.calculate();
        obj.print();
    }
}
