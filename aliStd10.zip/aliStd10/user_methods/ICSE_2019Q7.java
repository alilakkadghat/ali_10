package user_methods;
import java.util.*;
class ICSE_2019Q7
{
    public static void Series(int x,int n)
    {
        double S=0;
        for(int i=1;i<=n;i++)
        {
            S=S+(Math.pow(x,i));
        }
        System.out.println(S);
    }

    public static void Series(int p)
    {
        for (int i = 1; i<=p; i++)
        {
            System.out.println((i*i*i)-1+"");
        }

    }

    public static void Series()
    {
        double S=0;
        for (double i = 2; i<=10; i++)
        {
            S=S+(1/i);
        }
        System.out.println(S);
    }

    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number H³");
        int x=sc.nextInt();
        System.out.println("Enter the end limit");
        int n=sc.nextInt();
        System.out.println("Enter the number");
        int p=sc.nextInt();
        Series(x,n);
        Series(p);
        Series();
    }
}
