package user_methods;
import java.util.*;
class impure_func
{
    String name;
    double accBalance,withdrawVal;int accNo;
    public double transaction(double balance,double withdraw)
    {
        if(withdraw>balance)
            System.out.println("Sorry transaction not possible");
        else{
            balance=balance-withdraw;
            System.out.println("Transaction successful");
        }
        return balance;
    }

    void show(double bal)
    {
        System.out.println("Balance available:"+bal);
    }

    public static void main()
    {
        impure_func cus= new impure_func();
        cus.name="Mukesh kagalwala";
        cus.accNo=123;
        cus.accBalance=2000;
        cus.withdrawVal=500;
        System.out.println(cus.name+"--Account No:"+cus.accNo);
        cus.accBalance=cus.transaction(cus.accBalance,cus.withdrawVal);
        cus.show(cus.accBalance);
    }
}

