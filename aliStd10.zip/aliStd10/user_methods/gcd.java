package user_methods;

/*Question 2: Design a class named purefunction2 as per following specifications
Member methods
void accept()               :   accepts 2 numbers
void calculate(int , int)   :   calculates and displays
                                the gcd the lcm
                                (least common multiple) of the parameters passed  also displays the 
                                parameters value
                                 lcm=product of the numbers/gcd(greatest common divisor)
 */
import java.util.*;
class gcd
{

    public static void accept()
    {
        Scanner ob = new Scanner(System.in);
        int a,b;
        System.out.println("enter 2 numbers");
        a=ob.nextInt();
        b=ob.nextInt();
        calculate(a,b);
    }
    public static void calculate(int a1,int b1)
    {
        int g=0,i,prod=a1*b1,lcm;
        System.out.println("The first number is :"+a1);
        System.out.println("The second number is:"+b1);
        
        for(i=1;i<=(a1*b1);i++) 
        {
            if(((a1%i)==0)&&((b1%i)==0))
                g=i;
        }
        lcm=prod/g;
        System.out.println("Greatest Common Divisor  of the numbers is:"+lcm);
        System.out.println("Least common multiple of the numbers is:"+lcm);
    }
}
