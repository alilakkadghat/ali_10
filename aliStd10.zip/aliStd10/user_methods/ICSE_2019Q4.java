package user_methods;
/*
Design a class name ShowRoom with the following description:
 
Instance variables / Data members:
String name - To store the name of the customer
long mobno - To store the mobile number of the 
                         customer
double cost - To store the cost of the items
                        purchased
double dis - To store the discount amount
double amount - To store the amount to be
                               paid after discount

Member methods:

void input( ) - To input customer name, 
                         mobile number, cost
void calculate( ) - To calculate discount on
                              the cost of purchased items,
                          based on following criteria
                    Cost               Discount
                    <= 10000              5%   
                    >10000 and <=20000    10%
                    >20000 and <=35000    15%
                    More than 35000       20%
void display( ) - To display customer name , 
                  mobile number , amount to be
                  paid after discount.
Write a main method to create an object of the
class and call the above member methods
*/
import java.util.*;
class ICSE_2019Q4
{
    String n;
    double bill;int units;
    void accept()
    {
        Scanner ob=new Scanner(System.in);
        System.out.println("Enter name of the customer and number of units consumed");
        n=ob.nextLine();
        units=ob.nextInt();
    }
    void calculate()
    {
        if(units>=0 && units<=100)
            bill=2*units;
        else if(units>100 && units<=300)
            bill=2*100+(units-100)*3;
           else{ 
            double amt = 2*100+3*200+(units-300)*5;
            double surcharge = amt*0.025;
            bill = amt + surcharge;
        }
    }
    void print()
    {
        System.out.println("Name of the customer:"+n);
         System.out.println("Number of units consumed:"+units);
        System.out.println("Bill amount:"+bill);
    }

    public static void main()
    {
        ICSE_2019Q4 obj= new ICSE_2019Q4();
        obj.accept();
        obj.calculate();
        obj.print();
    }
}
