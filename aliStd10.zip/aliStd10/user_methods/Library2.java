package user_methods;

import java.util.*;
class Library2
{
    public static int b_no, ph_no,r_days;
    public static double f_amt;
    public static String s_name;
    Library2(int b, int p, int d, String s)
    {
        b_no = b;
        ph_no = p;
        r_days =  d;
        f_amt = 0.0d;
        s_name = s;
    }

    public static void main()
    {
        Library2 obj = new Library2(1234, 2222222, 10, "Computer App.");
        //obj.Accept();
        obj.Fine();
        System.out.println("Book No. \t Phone No \t Name \t\t No.of days \t Fine");
        obj.Display();
    }

    public static void Accept()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name of student");
        s_name = sc.nextLine();
        System.out.println(" Enter book number ");
        b_no = sc.nextInt();
        System.out.println("Enter phone number");
        ph_no = sc.nextInt();
        System.out.println("Enter number of books that the book returned late");
        r_days = sc.nextInt();
    }

    public static void Fine()
    {
        if (r_days<=7)
            f_amt = 20;
        else
            f_amt = 20 +(Math.ceil((r_days-7)/7.0)*30.00);
    }

    public static void Display()
    {
        System.out.println(b_no+"\t\t"+ph_no+"\t\t"+s_name+"\t\t"+r_days+"\t\t"+
            f_amt);
    }

}