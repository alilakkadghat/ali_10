package user_methods;

import java.util.*;
class constover
{ 
    public static int x,y,z,p;// declaration of global scope variables
    static Scanner sc = new Scanner(System.in);
    constover(int a, int b) // parameterised constructor
    {
        x=a;
        y=b;
        z=p=0;
    }

    constover() // Empty OR Default non-parameterised constructor
    {
        x=25;
        y=50;
        z=p=0;
    }

    public static void main()
    {
       // System.out.println("You are running parameterised constructor");
        constover obj = new constover(4,5); // creating an object
        obj.input();
        obj.sum();
        obj.product();
        obj.display();
       // System.out.println("You are running default constructor");
        constover obj1 = new constover(); // creating an object
        obj.input();
        obj1.sum();
        obj1.product();
        obj1.display();
    }

    public static void sum()
    {
        System.out.println("You are in sum function");
        z = x+y;
    }

    public static  void input()
    {
        System.out.println("You are in Input function");

        System.out.println(" Enter an Integer number");
        x = sc.nextInt(); 
        System.out.println(" Enter another Integer number");
        y = sc.nextInt(); 
    }

    public static void display()
    { 
        System.out.println("You are in print function");
        System.out.println(" x = "+x);
        System.out.println(" y = "+y);
        System.out.println(" sum = "+z);
        System.out.println(" product = "+p);
    }

    public static void product()
    {
        System.out.println("You are in product function");
        p = x*y;
    }    
}