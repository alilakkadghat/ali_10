package user_methods;
import java.util.*;
class ICSE_2018Q7
{
    public static double r,h,l,b;
    private static void accept()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the radius");
        r=sc.nextDouble();
        System.out.println("Enter the Heigth");
        h=sc.nextDouble();
        System.out.println("Enter the Lenght");
        l=sc.nextDouble();
        System.out.println("Enter the breath");
        b=sc.nextDouble();
    }

    private static double volume(double R)
    {
        double v=4.0/3*22.0/7*(R*R*R);
        return v;
    }

    private static double volume(double H,double R)
    {
        double v=22.0/7*(R*R)*H;
        return v;
    }

    private static double volume(double L,double B,double H)
    {
        double v=L*B*H;
        return v;
    }

    public static void main()
    {
        accept();
        System.out.println("volume of a sphere=  "+volume(r));
        System.out.println("volume of a cylinder=  "+volume(h,r));
        System.out.println("volume of a cuboid=  "+volume(l,b,h));
    }
}
/*
class volume12
{
    private static double volume(double R)
    {
        double v=4.0/3*22.0/7*(R*R*R);
        return v;
    }

    private static double volume(double H,double R)
    {
        double v=22.0/7*(R*R)*H;
        return v;
    }

    private static double volume(double L,double B,double H)
    {
        double v=L*B*H;
        return v;
    }

    public static void main()
    {
        System.out.println("volume of a sphere=  "+volume(2.0));
        System.out.println("volume of a cylinder=  "+volume(3,2.0));
        System.out.println("volume of a cuboid=  "+volume(2,2,4));
    }
}
*/