package user_methods;
/*
Design a class student_details as per following specifications
Data members
int  roll   :   to store roll  number
int std     :   to store standard
int gr      :   to store general register number
char div    :   to store division of student
String nm   :   to store students name
String hse  :   to store the students house
Member methods
void accept()   :   accepts students details
void display () :   displays students details
void main()     :   invokes the other methods     
 */
import java.util.*;
class student_details
{
    public static int roll,std,gr;
    public static String nm,hse;
    public static char div;
    public static void accept()
    {
        Scanner ob=new Scanner(System.in);
        System.out.println("Enter students name,roll no,gr number, std, div,along with house");
        nm=ob.nextLine();
        roll=ob.nextInt();
        gr=ob.nextInt();
        std=ob.nextInt();
        div=ob.next().charAt(0);
        ob.nextLine();
        hse=ob.nextLine();
    }

    public static void display()
    {
        System.out.println("Students name:"+nm);
        System.out.println("Roll number:"+roll);
        System.out.println("Gr number:"+gr);
        System.out.println("Standard:"+std);
        System.out.println("Division:"+div);
        System.out.println("House:"+hse);
    }

    public static void main()
    {
        accept();
        display();
    }
}
