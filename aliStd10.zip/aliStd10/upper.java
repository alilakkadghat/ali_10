import java.io.*;
    class upper
    {
         public static void main ()throws IOException
      {
       InputStreamReader read=new InputStreamReader(System.in);
       BufferedReader in=new BufferedReader(read);
       System.out.println("Enter your Name");
       String a=in.readLine();
       char ch=a.charAt(0);char chr=0;
        System.out.println("name Entered\t"+a);
       if(Character.isUpperCase(ch)==true){
         System.out.println("You are good in English");
        }
         else{
         chr=Character.toUpperCase(ch);
          System.out.println("You are bad in English");
           System.out.println("The first letter is always capital\nlike this:"+chr+charRemoveAt(a,0));
        
        }
        }
        private static String charRemoveAt(String str, int p) {  
              return str.substring(0, p) + str.substring(p + 1);  
           }  
        }