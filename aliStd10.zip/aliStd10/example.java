class example
{
    public static void main()
    {
        array.arraysortcheat.main();
    }
}