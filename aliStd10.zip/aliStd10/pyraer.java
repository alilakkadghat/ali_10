class pyraer
{
    public static void drawPyramidOfNumrgbers() { 
        for (int i = 1; i <=5; i++)
        { 
            /* for (int j = 0; j < 5 - i; j++) 
            { 
            System.out.print(" ");
            }*/
            for (int k = 5; k >= i; k--)
            { 
                System.out.print(k + " "); 
            } 
            System.out.println(); 
        } 
    } 

    public static void twentyfifteen() { 
        for (int i = 1; i <=5; i++)
        { 
            for (int k = 1; k <= i; k++)
            { 
                if(k%2==0)
                    System.out.print("#"+ " "); 
                else
                    System.out.print("*"+ " ");
            } 
            System.out.println(); 
        } 
    } 

    public static void twentysixteen() { 
        String s="ICSE";
        for (int i = 0; i <4; i++)
        { 
            for (int k=0; k <=i; k++)
            { 
                System.out.print(s.charAt(k)+ " "); 
            } 
            System.out.println(); 
        } 
    } 
}

