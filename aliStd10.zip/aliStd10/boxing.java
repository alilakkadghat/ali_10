class boxing{
    public static void main(){
        String s ="indiz";
         String s1 ="TrUe";
          String s2 ="False";
        boolean x=Boolean.valueOf(s);
        boolean y=Boolean.valueOf(s1);
        boolean z=Boolean.valueOf(s2);
        System.out.println(x+" "+y+" "+z);
        int a = 10; int b = 20;
        
String m = Integer.toString(a);
String t = Integer.toString(b);
System.out.println((m+t));


    }
}
    