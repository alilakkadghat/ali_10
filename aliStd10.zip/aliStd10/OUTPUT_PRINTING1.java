class OUTPUT_PRINTING1
{
    public static void main()
    {
        int i,count=1;
        for(i=1;i<=10;i++,count++)
        {
            if(count<=3)
                System.out.print(i+"\t");
            else
            {
                count=0;
                --i;
                System.out.println();
            }
        }
    }
}
