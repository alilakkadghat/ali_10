import java.util.*;
class ICSE_Q7
{
public static void proneg()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter data");
        String a=sc.nextLine();
        String b=sc.nextLine();
        String c=""; 
        for (int i = 0; i < a.length(); i++) 
        {
         char ch=a.charAt(i);
         char sh=b.charAt(i);
         c=c+ch+sh;
        }
        System.out.println(c);
            }
        }
       