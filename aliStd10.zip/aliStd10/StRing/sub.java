
package StRing;
import java.util.*;
class sub
{
public static void main()
{
Scanner sc = new Scanner(System.in);
String sent, w="";
System.out.println(" enter a sentence");
sent = sc.nextLine(); //Sachin Ramesh Tendulkar
int p =sent.lastIndexOf(' ');
String m = sent.substring(p+1);
System.out.println(m);
}
}