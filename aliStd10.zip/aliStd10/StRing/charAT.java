package StRing;
import java.util.*;
class charAT
{
    public static void main()
    {
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter a sentence");
        String s =sc.nextLine();
        for(int i=0;i<s.length();i++)
        {
            System.out.println(s.charAt(i));
        }
        for(int i=s.length()-1;i>=0;i--)
        {
            System.out.print(s.charAt(i));
        }
    } 
}