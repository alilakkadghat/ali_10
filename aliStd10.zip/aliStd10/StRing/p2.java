package StRing;
import java.util.*;
class p2 extends p5
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine(); //"Sachin Ramesh Tendulkar I love my country"
s=s+" ";  
String w="", h="";
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);  
if(ch != ' ')
w=w+ch;    
else
{
    h = h+w.charAt(0)+".";  // S.R.T.
    w="";
}                    
}   
 System.out.println(h);         
}
}