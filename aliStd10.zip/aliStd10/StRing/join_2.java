package StRing;

import java.util.*;
class join_2
{
public static void main()
{
Scanner sc = new Scanner(System.in);
int c=0;
System.out.println("Enter a statement");    
String s = sc.nextLine(); //"Sachin Ramesh Tendulkar I love my country"
s=s+" ";
String w="";
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);  
if(ch != ' ')
w=w+ch;//  
else
{
    System.out.println(w); 
    w="";
}                    
}                     
}
}