package StRing;

import java.util.*;
class trim
{
public static void main()
{
Scanner sc = new Scanner(System.in);
int c=0;
System.out.println("Enter a statement");    
String s = sc.nextLine(); //"Sachin Ramesh Tendulkar I love my country"
s=s+" ";
String w="",h="";
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);  
if(ch != ' ')
w=ch+w;//  w=w+ch;
else
{
    h=w+h+" ";// h=h+w+" ";
    w="";
}                    
}      
System.out.print(h.trim());               
}
}