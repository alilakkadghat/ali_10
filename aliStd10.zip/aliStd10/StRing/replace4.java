package StRing;

class replace4
{
public static void main()
{
String s = "This earth is round and This moon is square Land";

String w = s.replace(" is "," * ");
//String w = s.replace(' ','.');
System.out.println("Before replace - "+ s);
System.out.println("After replace - "+w);
}
}