package StRing;

class UpperCheck
{
public static void main()
{
String s = "ICSE - exam 2021-22";
char ch = s.charAt(0); // I
System.out.println("      Upper case letter");  
System.out.println(Character.isUpperCase(ch)); // true
System.out.println(Character.isUpperCase(s.charAt(15)));  // false
if(Character.isUpperCase(ch))//(ch>='A' && ch<='Z') //(ch>=65 && ch<=90)//
System.out.println("Capital letter ");
else
System.out.println("Not a capital");
}
}