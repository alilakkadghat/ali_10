package StRing;
class CaseConversion
{
public static void main()
{
String s = "Sachin Ramesh Tendulkar"; // storing a statement
System.out.println(s); // Sachin Ramesh Tendulkar
System.out.println(s.toUpperCase());
System.out.println(s.toLowerCase());
String x = "I love MUMbaI. - 400010".toUpperCase();
System.out.println(x);
String y = "I love MUMbaI. - 400010".toLowerCase();
System.out.println(y);
} 
}