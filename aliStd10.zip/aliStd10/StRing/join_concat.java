package StRing;

class join_concat
{
public static void main()
{
String s1 = "hello";
System.out.println("old value = "+s1);
String s2 = "how are you";
String s3 = s1.concat(" ".concat(s2)); //s1+" "+s2;
//String s3 = s1.concat(s2); //s1+s2;
System.out.println("new value = "+s3);
}
}