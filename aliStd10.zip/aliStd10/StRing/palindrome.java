package StRing;

import java.util.*;
class palindrome
{
public static void main()
{
Scanner sc = new Scanner(System.in);
String w="";
System.out.println("enter a word");
String s = sc.nextLine();
for(int i = 0; i<s.length(); i++)//for(i=s.length()-1;i>=0;i=i-1)
{
char ch = s.charAt(i);
w = ch + w;                  //w=w+ch;
}
System.out.println("Original Word = "+s);
System.out.println("Reversed Word = "+w);
if (s.equalsIgnoreCase(w))
System.out.println("it is a palindrome ");
else
System.out.println("it is not a palindrome");
}
}