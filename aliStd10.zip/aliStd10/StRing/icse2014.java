package StRing;
class icse2014
{
public static void main()
{
//System.out.print("\f");
String s = "c:\\users\\admin\\pictures\\flower.jpg";
int x = s.lastIndexOf('\\'); //22 (0-21
System.out.println("path:       "+s.substring(0,x)); //c:\\users\\admin\\pictures
String y = s.substring(x+1); //flower.jpg
int z = y.lastIndexOf('.'); //6
System.out.println("File name:  "+y.substring(0,z));//flower
System.out.println("Extension:  "+y.substring(z+1));// jpg
}
}