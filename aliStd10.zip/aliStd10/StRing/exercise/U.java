package StRing.exercise;
import java.util.*;
class U
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine(); 
int c=0,d=0,a=0;
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);     
if(Character.isDigit(ch))
c=c+1;
else if(Character.isLetter(ch))
d=d+1;
else
a=a+1;
}    
System.out.println("Alphabets:="+d);
System.out.println("Digits:="+c);
System.out.println("Special Characters:="+a);
}    
}      
