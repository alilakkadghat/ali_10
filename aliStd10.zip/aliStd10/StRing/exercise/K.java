package StRing.exercise;
import java.util.*;
class K
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine();
System.out.println("Enter word to search for");    
String a = sc.nextLine();
s=s+" "; 
String w = "";
int c=0;
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i); 
if(ch != ' ')
w = w+ch;   
else
{
if(w.equalsIgnoreCase(a)){
c++;
}
w="";
}    
} 
System.out.println("frequncy of input word '"+a+"'is:="+c);    
}      
}