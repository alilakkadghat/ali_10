package StRing.exercise;
import java.util.*;
class test2
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine(); 
String w ="";
int c=0,j=0,x=0,k=0;
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);   
j++;//imp   
if(ch == ' ')
c++;    
if(ch == 'a' || ch == 'A'||ch == 'e' || ch == 'E'||ch == 'i' || ch == 'I'||ch == 'o' || ch == 'O'||ch == 'u' || ch == 'U')
x++; 
}   
s=s+" "; //imp
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);    
if(ch != ' ')
w = w + ch; 
else
{
k++; 
w="";
}    
}    
System.out.println("Frequency of words   "+k);
System.out.println("Frequency of spaces   "+c);
System.out.println("Frequency of characters   "+j);
System.out.println("Frequency of vowels   "+x);
}      
}