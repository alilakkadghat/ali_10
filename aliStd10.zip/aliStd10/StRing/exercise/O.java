package StRing.exercise;
import java.util.*;
class O
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a statement");    
        String s = sc.nextLine(); 
        s=s+" "; 
        s=s.toLowerCase();
        String w = "";
        int j=0;
        for(int i = 0;i<s.length(); i=i+1)
        {
            char ch = s.charAt(i); 
            if(ch==' ')
                j=j+1;
            if(ch != ' '){
                w = w + ch; 
            }
            else
            {
                if(j%2==1)
                    System.out.print(w.toUpperCase()+" ");    
                else
                    System.out.print(w+" ");
                w="";
            }    
        }    
    }      
}