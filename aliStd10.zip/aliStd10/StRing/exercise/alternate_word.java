package StRing.exercise;
import java.util.*;

class alternate_word{
public static void main1()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");
String sent = sc.nextLine(); // hello how are you? I am fine. 
sent = sent.toUpperCase() + " ";  
int i, c=0;
String w ="",h="";
for(i=0; i<sent.length();i++)
{
    char ch = sent.charAt(i);
    if(ch != ' ')
    w=w+ch; //how
    else
    {
        c=c+1;
        if(c%2 == 0)
        w=w.toLowerCase();
        h = h+w+" ";
        w = "";
    }
}
System.out.println(h.trim());
    }
}