package StRing.exercise;
import java.util.*;
class TPS_Q5
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentence");
        String a=sc.nextLine();
        a=a.toUpperCase();//COMPUTER APPLICATION
        String w="";
        for(int i=0;i<a.length();i++){
            char ch=a.charAt(i);//c o m
            if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
                continue;
            w=w+ch;//c m
        }
        System.out.println(w);
    }
    
    
    public static void main1()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentence");
        String a=sc.nextLine();
        a=a.toUpperCase()+" ";//COMPUTER APPLICATION
        String w="",h="";
        for(int i=0;i<a.length();i++){
            char ch=a.charAt(i);   
            if(ch!=' ')
                w=w+ch;//computer
            else{
                for(int j=0;j<w.length();j++){
                    char sh=w.charAt(j);//c o
                    if(sh=='A'||sh=='E'||sh=='I'||sh=='O'||sh=='U')
                        continue;
                    h=h+sh;//c m
                }
                w="";
            }
        }
        System.out.println(h.trim());
    }
}
