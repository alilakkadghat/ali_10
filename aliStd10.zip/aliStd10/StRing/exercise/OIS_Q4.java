
package StRing.exercise;
/*
 * Write a program to accept a String and convert it into lowercase if its in uppercase and
display the new word by replacing only the vowels with the characters following it.
cg: SampleInput:computer
SampleOutput: cpmpvtr
 */
import java.util.*;
class OIS_Q4
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a String");
String a=sc.nextLine();
a=a.toLowerCase();
for(int i=0;i<a.length();i++){
    char ch=a.charAt(i);
    if(ch == 'a'||ch == 'e' ||ch == 'i' ||ch == 'o'||ch == 'u'){
        int f=(int)ch+1;
        char k=(char)f;
        a=a.replace(ch,k);
    }
}
System.out.println(a);
}

public static void mais()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a String");
String a=sc.nextLine();
a=a.toLowerCase();
String w="";
for(int i=0;i<a.length();i++){
    char ch=a.charAt(i);
    if(ch == 'a'||ch == 'e' ||ch == 'i' ||ch == 'o'||ch == 'u')
       ch++;
       w=w+ch;
}
System.out.println(w);
}
}