package StRing.exercise;
import java.util.*;
class CCS_Q5
{
public static void main()
{
Scanner sc = new Scanner(System.in);
int x=0,y=0,z=0,c=0,m=0;
System.out.println("Enter a statement");    
String s = sc.nextLine();
s=s.toLowerCase(); //s=s.toLowerCase();
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);  
if(ch == 'a')
x=x+1; 
else if(ch == 'e')
y=y+1;
else if(ch == 'i')
z=z+1; 
else if(ch == 'o')
c=c+1;
else if(ch == 'u')
m=m+1; 
}
if(x>=1||y>=1||z>=1||c>=1||m>=1)
System.out.println("vowels \t  freqency");
if(x>=1)
System.out.println("a   "+x);
if(y>=1)
System.out.println("e   "+y);
if(z>=1)
System.out.println("i   "+z);
if(c>=1)
System.out.println("o   "+c);
if(m>=1)
System.out.println("u   "+m);
}
}