package StRing.exercise;
import java.util.*;
class V
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a statement");     
        String s = sc.nextLine(); 
        String w="";
        s=s+" ";
        for (int i = 0; i <s.length(); i++) {
            if (s.charAt(i) == ' ') {
                int wordLen = w.length();
                for (int j = 0; j < wordLen - 1; j++) {
                    if (w.charAt(j)== w.charAt(j + 1)) {
                        System.out.println(w);
                        break;
                    }
                }

                w = "";
            }
            else {
                w+= s.charAt(i);
            }

        }
    }
}
 