package StRing.exercise;
import java.util.*;
class CCS_Q3
{
public static void main()
{
Scanner sc = new Scanner(System.in);
int c=0;
System.out.println("Enter a statement");    
String s = sc.nextLine(); 
s=s.toLowerCase();
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);  
if(ch =='a'||ch == 'e'||ch == 'i'||ch == 'o'||ch == 'u')
System.out.println(ch+"\t"+(int)ch);
else
c=c+1; 
}
System.out.println("Frequency of consonents = "+c);
}
}