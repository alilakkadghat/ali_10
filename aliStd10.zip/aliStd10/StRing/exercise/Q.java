package StRing.exercise;
import java.util.*;
class Q
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine();
s=s.toLowerCase(); 
char ch = Character.toUpperCase(s.charAt(0));
String w = "";
w=w+ch+s.substring(1); 
System.out.println(w); 
}      
}