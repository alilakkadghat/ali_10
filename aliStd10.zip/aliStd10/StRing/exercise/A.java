package StRing.exercise;
import java.util.*;
class A
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");
String s = sc.nextLine();
int i;
String w = "";
for(i=s.length()-1;i>=0;i=i-1)
{
char ch = s.charAt(i);
w=w+ch;  // Full string in reverse
}
System.out.println(w);
}
}