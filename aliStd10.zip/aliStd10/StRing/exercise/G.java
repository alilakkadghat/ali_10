package StRing.exercise;
import java.util.*;
class G
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine(); 
s=s+" "; 
String w ="";
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);     
if(ch != ' ')
w = w + ch; 
else
{
System.out.println(w+"    "+w.length());  
w="";
}    
}    
}      
}