package StRing.exercise;
import java.util.*;
class C
{
    public static void main () {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentence");
        String str=sc.nextLine();
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch == 'a'||ch=='A') {
                count++;
            }
        }
        System.out.println("Frequency of " + "'A' " + " = " + count);
    }
}