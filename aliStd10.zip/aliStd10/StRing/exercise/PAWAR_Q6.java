package StRing.exercise;
/*
Write a program to accept a sentence. Display the sentence in reversing order of its word.
Sample Input: Computer is Fun
Sample Output: Fun is Computer
 */
import java.util.*;
class PAWAR_Q6
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a String");  
String a=sc.nextLine();
a=" "+a;//a=a+" "-->wrong
String w="",h="";
for(int i=a.length()-1;i>=0;i--){
   char ch=a.charAt(i); //n
   if(ch!=' ')
   w=ch+w;
   else{
    h=h+w+" ";
   w="";
}
}
System.out.println(h);
}
public static void main1()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a String");  
String a=sc.nextLine();
a=a+" ";
String w="",h="";
for(int i=0;i<a.length();i++){
   char ch=a.charAt(i); //n
   if(ch!=' ')
   w=w+ch;
   else{
    h=w+" "+h;
   w="";
}
}
System.out.println(h);
}
}