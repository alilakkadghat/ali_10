package StRing.exercise;
import java.util.*;
class alternate_char
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine();
char ch=0;
String w="";
for(int i = 0;i<s.length(); i=i+1)
{
ch = s.charAt(i);       
if(ch>='a'&&ch<='z'){
ch=Character.toUpperCase(ch);
w=w+ch;
}
else if(ch>='A'&&ch<='Z'){
ch=Character.toLowerCase(ch);
w=w+ch;
}
else
w=w+ch;
} 
System.out.println(w);
}
}
