package StRing.exercise;
import java.util.*;
class J
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine();
s=s+" "; 
String w = "";
int c=0;
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i); 
if(ch != ' ')
w = w+ch;   
else
{
if(w.equalsIgnoreCase("and")){
c++;
}
w="";
}    
} 
System.out.println("frequncy of 'And':= "+c);    
}      
}