package StRing.exercise;
import java.util.*;
class D
{
    public static void main () {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentence");
        String str=sc.nextLine();
        str=str+" ";
        int count = 0;
        String w="";
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch != ' ') {
                w=w+ch;
            }
            else{
                count++;
                w="";
            }
        }
        System.out.println("Frequency of " + "Words" + " = " + count);
    }
}