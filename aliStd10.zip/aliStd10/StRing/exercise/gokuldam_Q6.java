package StRing.exercise;
/*
 * Define a class to accept a string, convert it into 
 * lowercase and replace vowels with ‘*’
and consonants with ‘@’. Display the new string.
Input: Computer
Output: @*@@*@*@
 */
import java.util.*;
class gokuldam_Q6
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a String");
String a=sc.nextLine();
a=a.toLowerCase();
String w="";
for(int i=0;i<a.length();i++){
    char ch=a.charAt(i);
    if(ch == 'a'||ch == 'e' ||ch == 'i' ||ch == 'o'||ch == 'u')
    a=a.replace(ch,'*');
    else
    a=a.replace(ch,'@');
}
System.out.println(a);
}
}