package StRing.exercise;
import java.util.*;
class CCS_Q6
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");
String sent = sc.nextLine(); // development
//sent = sent.toUpperCase();  
int i, c=0;
String w ="",h="", m="";

for(i=0; i<sent.length();i++)
{
    char ch = sent.charAt(i);
    m=ch+m;//
    if (i%2 == 0)
    {
    w=w+ch; 
    }
}
for(i=0; i<m.length();i++)
{
    char ch = m.charAt(i);
    if (i%2 == 0)
    {
    h=h+ch; 
    }
}
System.out.println(w);
System.out.println(h);
System.out.println(w.concat(h));
    }
}