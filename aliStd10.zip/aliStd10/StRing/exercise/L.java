package StRing.exercise;
import java.util.*;
class L
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine();
String w = s.replace(" is "," was ");
System.out.println(w);   
}      
}