package StRing.exercise;
/*
 * Input a sentence. Find and print the shortest word.
 * Also print number of consonants of the shortest word,
assuming only alphabets and digits are present in the word, 
after converting into lowercase.
 */
import java.util.*;
class LoYOLa_Q3
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a String");
        String a=sc.nextLine();
        a=a.toLowerCase()+" ";
        String w="",b="";int h=10000,c=0;
        for(int i=0;i<a.length();i++){
            char ch=a.charAt(i);
            if(ch!=' ')
                w=w+ch;
            else{
                int s=w.length();//5 2
                if(s<h){
                    h=s;
                    b=w;
                }
                w="";
            }
        }
        for(int i=0;i<b.length();i++){
            char sh=b.charAt(i);
            c++;
           if(sh == 'a'|| sh == 'e' || sh == 'i' || sh == 'o'|| sh == 'u')
                c--;
        }
        System.out.println("shortest word = "+b+"\n No of consonents in  "+b+" are "+c);
    }
}
