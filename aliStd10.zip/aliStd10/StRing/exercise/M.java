package StRing.exercise;
import java.util.*;
class M
{
public static void main()
{
Scanner sc = new Scanner(System.in);
String a="the world is round and the moon is squre and the sun is triangle and the stars are rectangles";
System.out.println(a);   
System.out.println("select a word you want to replace");    
String s = sc.next();
System.out.println("select a word you want to replace with");    
String c = sc.next();
String w = a.replace(s,c);
System.out.println(w);   
}      
}