package StRing.exercise;
import java.util.*;
class T extends alternate_char
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine();
char ch=0,sh=0;
for(int i = 0;i<s.length(); i=i+1)
{
ch = s.charAt(i); 
sh = s.charAt(i);      
if(Character.isUpperCase(ch)){
ch=Character.toLowerCase(ch);
System.out.print(ch+" "); }
if(Character.isLowerCase(sh)){
sh=Character.toUpperCase(sh);
System.out.print(sh+" "); 
}
} 
/*
 * ch = s.charAt(i);      
if(Character.isUpperCase(ch)){
ch=Character.toLowerCase(ch);
System.out.print(ch); }
else{
ch=Character.toUpperCase(ch);
System.out.print(ch); 
}
 */
}
}