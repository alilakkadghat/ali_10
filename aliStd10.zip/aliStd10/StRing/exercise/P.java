package StRing.exercise;
import java.util.*;
class P
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a statement");    
        String s = sc.nextLine();
        s=s+" "; 
        String w = "",a="";
        int h=0;
        for(int i = 0;i<s.length(); i=i+1)
        {
            char ch = s.charAt(i); 
            if(ch != ' ')
                w = w+ch;   
            else
            {
                int l=w.length();
                if(l>=h){
                    h=l;
                    a=w;
                }
                w="";
            }    
        } 
        System.out.println(a);    
    }      
}