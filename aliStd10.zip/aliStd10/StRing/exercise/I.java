package StRing.exercise;
import java.util.*;
class I
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a statement");    
        String s = sc.nextLine(); 
        s=s.toUpperCase();
        s=s+" "; 
        String w = "";char h;//h="";
        for(int i = 0;i<s.length(); i=i+1)
        {
            char ch = s.charAt(i);     
            if(ch != ' ')
                w = w + ch; 
            else
            {
                h=w.charAt(0);//h=h+w.charAt(0)+".";
                System.out.print(h+".");  //
                w="";
            }    
        }    
        //System.out.print(h.trim());
    }      

    public static void main1()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a statement");    
        String s = sc.nextLine(); 
        s=s.toUpperCase();
        //s=s+" "; 
        int l1=s.lastIndexOf(' ');
        String w = "";String h="";
        String s1=s.substring(l1+1);
        for(int i = 0;i<s.length(); i=i+1)
        {
            char ch = s.charAt(i);  //sachin ramesh tendulkar   
            if(ch != ' ')
                w = w + ch; //sachin       
            else
            {
                h=h+w.charAt(0)+".";//s.r
                w="";
            }    
        }   
        h=h+s1;
        System.out.print(h); 
    }

    public static void main2()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a statement");    
        String s = sc.nextLine(); 
        s=s.toUpperCase();
        //s=s+" "; 
        int l1=s.lastIndexOf(' ');
        String w = "";String h="";
        String s1=s.substring(l1+1);
        for(int i = 0;i<s.length(); i=i+1)
        {
            char ch = s.charAt(i);  //sachin ramesh tendulkar   
            if(ch != ' ')
                w = w + ch; //sachin       
            else
            {
                h=h+w.charAt(0)+".";//s.r
                w="";
            }    
        }   
        h=s1+" "+h;
        System.out.print(h); 
    }
}