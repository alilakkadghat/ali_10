package StRing.exercise;
/*
 */
import java.util.*;
class PArh
{
public static void main1()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a String");  
String a=sc.nextLine();
a=a+" ";
String w="",h="",p="",d="";
for(int i=0;i<a.length();i++){
   char ch=a.charAt(i); //n
   if(ch!=' ')
   w=w+ch;//her
   else{
for(int j=0;j<w.length();j++){
    char sh=w.charAt(j);//h e r
    if(sh=='a'||sh=='e'||sh=='i'||sh=='o'||sh=='u')
    h=h+sh;//e
    else
    p=p+sh;//hr
}
    d=d+h+p+" ";
    w="";p="";h="";
   }
}
System.out.println(d);
}
}