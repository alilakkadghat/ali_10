package StRing;
import java.util.*;
class vowels
{
public static void main()
{
Scanner sc = new Scanner(System.in);
int c=0;
System.out.println("Enter a statement");    
String s = sc.nextLine(); //"Sachin Ramesh Tendulkar I love my country"
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);  
if(ch == 'a' || ch == 'A'||ch == 'e' || ch == 'E'||ch == 'i' || ch == 'I'||ch == 'o' || ch == 'O'||ch == 'u' || ch == 'U')
c=c+1; 
}
System.out.println("Frequency of vowels = "+c);
}
}