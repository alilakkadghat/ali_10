package StRing;


/*Write a program to accept a word from user and store it 
in variable wrd, search for a character entered by user and 
print whether that character exist or not. Design program to 
display error message if the character to be searched 
does not exist in the word*/
import java.util.*;
class character_search
{
    public static void main()
    {
        int pos;
        Scanner ob=new Scanner(System.in);
        System.out.println("enter the word");
        String wrd=ob.nextLine();
        System.out.println("enter the character to be searched");
        char src=ob.next().charAt(0);
        for(int i=0;i<wrd.length();i++)
        {
            if(wrd.charAt(i)==src)
            {
             pos=i;
             System.out.println("character to be searched exist ");
             System.out.println("character position  "+(pos+1));
             System.exit(0);
            }
        }
        System.out.println("character to be searched does not exist ");
    }
} 
