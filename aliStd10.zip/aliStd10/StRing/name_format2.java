package StRing;
/*
Write a program to accept persons full name and 
print it as per the format specified 
For example if the name entered is MOHANDAS  KARAMCHAND GANDHI
 the output will be
 M K GANDHI
For example if the name entered is MOHAMMAD YUSUF SALIM KHAN 
the output will be
 M Y S KHAN*/
import java.util.*;
class name_format2
{
    public static void main()
    {
        String name;
        int i,l;
        Scanner ob=new Scanner(System.in);
        System.out.println("enter persons full name");
        name=ob.nextLine();
        l=name.length();
        name =name.trim(); // used to remove blank space if any before the first alphabet and after the last alphabet
        System.out.println("name entered is :-  \n"+name);
        System.out.print("formatted name is : ");
        int pos=name.lastIndexOf(" ");
        for(i=0;i<pos;i++)
        { 
            char x=name.charAt(i);
            if(i==0)
                System.out.print(x+" ");
            else if(x==' '&& name.charAt(i+1)!=' ')
                System.out.print(name.charAt(i+1)+" ");
        }
        System.out.print(name.substring(pos+1));
    }
}
     
