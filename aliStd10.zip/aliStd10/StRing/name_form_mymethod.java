package StRing;
/*
Write a program to accept persons full name and 
print it as per the format specified 
For example if the name entered is MOHANDAS  KARAMCHAND GANDHI 
the output will be
 M.K.G
For example if the name entered is MOHAMMAD YUSUF SALIM KHAN 
the output will be
 M.Y.S.K*/
import java.util.*;
class name_form_mymethod extends name_format1
{
    public static void main()
    {
        String name;
        int i,l;
        Scanner ob=new Scanner(System.in);
        System.out.println("enter persons full name");
        name=ob.nextLine();
        name=" "+name;
        l=name.length();
        System.out.println("name entered is :-  \n"+name);
        System.out.print("formatted name is : ");
        for(i=0;i<l;i++)
        { 
             if(name.charAt(i)==' '&& name.charAt(i+1)!=' ')
                 System.out.print(name.charAt(i+1)+".");
        }
    }
}   
