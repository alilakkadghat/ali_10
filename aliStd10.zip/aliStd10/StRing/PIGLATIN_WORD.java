package StRing;
/*
Write a program that encodes a word into piglatin. To translate word into Piglatin word convert the
 word into uppercase and then place the first vowel of the original word as the start of the new word
 and along with the remaining alphabets. The alphabets before the vowel being shifted to 
 the end followed by AY
 Sample Input  : london
 Sample Output : ONDONLAY
 
 Sample Input  : Olympics
 Sample Output : OLYMPICSAY*/
import java.util.*;
class PIGLATIN_WORD
{
    public static void main()
    {
        int i,l,pos=0;
        String p_word="";
        Scanner ob= new Scanner(System.in);
        System.out.println("enter a word");
        String word=ob.next();
        System.out.println("original word is:  "+ word);
        word=word.toUpperCase();
        l=word.length();
        for(i=0;i<l;i++)
        {
            char x= word.charAt(i);
            if(x=='A'||x=='E'||x=='I'||x=='O'||x=='U')
            {
                pos=i;
                break;
            }
            }
            
        p_word=word.substring(pos)+word.substring(0,pos)+"AY";
        System.out.println("Piglatin conversion of word is  : "+p_word);
      
    }
}
