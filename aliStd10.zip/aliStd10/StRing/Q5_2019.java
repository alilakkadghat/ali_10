package StRing;
import java.util.*;
class Q5_2019{
    public static void main(){
        for(int i =65;i<=90; i=i+1)
        {
            System.out.println((char)i+"   "+i);
        }

    }
}

