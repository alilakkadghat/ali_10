package StRing;

class check1_indexOf
{
public static void main()
{
String x = "Computer teacher";
int a = x.indexOf('e');
System.out.println(a); //--> 6
int d = x.indexOf('e',7);//7 is to pick middle variable
System.out.println(d); //--> 6
int c = x.lastIndexOf('e');
System.out.println(c); //--> 14
int b = x.indexOf('z');
System.out.println(b); //--> -1
}
}
//inverse of charAt