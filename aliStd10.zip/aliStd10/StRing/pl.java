package StRing;
/*
Write a program to accept persons full name and 
print it as per the format specified 
For example if the name entered is MOHANDAS  KARAMCHAND GANDHI 
the output will be
M.K.G
For example if the name entered is MOHAMMAD YUSUF SALIM KHAN 
the output will be
M.Y.S.K*/
import java.util.*;
class pl
{
    public static void main()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a statement");    
        String s = sc.nextLine(); //"MOHANDAS KARAMCHAND GANDHI"
        s=s+" ";  
        String w="", h="";
        for(int i=0;i<s.length();i++)
        { 
            char ch=s.charAt(i);
            if(ch!=' ')
                w=w+ch;
            else{
                h=h+w.charAt(0)+".";   
                w="";
            }
        }
        int l=h.length()-1;
        System.out.println(h.substring(0,l));
    }
}   
