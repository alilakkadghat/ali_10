package StRing;

class simple_replace
{
public static void main()
{
String s = "COMPUTER application";
char ch1 = s.charAt(10);
char ch2 = '#';
System.out.println("Original String "+s);
s = s.replace(ch1,ch2);
System.out.println("New String "+s.replace('P','@'));

}
}