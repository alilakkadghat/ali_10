package StRing;
class Q7_2015
{
    public void joystring(String s, char ch1, char ch2) {
        String newStr = s.replace(ch1, ch2);
        System.out.println(newStr);
    }
    
    public void joystring(String s) {
        int f = s.indexOf(' ');
        int l = s.lastIndexOf(' ');
        System.out.println("First index:  " + f);
        System.out.println("Last index:  " + l);
    }
    
    public void joystring(String s1, String s2) {
        s1=s1+" ";
        s1=s1.concat(s2);
        System.out.println(s1);
    }
    
    public static void main() {
        Q7_2015 obj = new Q7_2015();
        obj.joystring("TECHNALAGY", 'A', 'O');
        obj.joystring("Cloud computing means Internet based computing");
        obj.joystring("COMMON WEALTH", "GAMES");
    }
}