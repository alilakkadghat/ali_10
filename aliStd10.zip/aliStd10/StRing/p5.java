package StRing;
import java.util.*;
class p5
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine(); //"Sachin Ramesh Tendulkar I love my country"
String w="", h="";
w=w+s.charAt(0)+".";  // S.R
for(int i = 1;i<s.length(); i=i+1)
{
char ch = s.charAt(i);  
if(ch == ' ')
w=w+s.charAt(++i)+".";  //  Tendulkar                   
}   
 System.out.println(w);         
}
}