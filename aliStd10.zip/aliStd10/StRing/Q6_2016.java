package StRing;

import java.util.*;
class Q6_2016
{
public static void main()
{
Scanner sc = new Scanner(System.in);
String w="";
System.out.println("enter a word");
String s = sc.nextLine();
int l=s.length();
for(int i = 0; i<l; i++)
{
char ch = s.charAt(i);
w = ch + w;
}
System.out.println("Original Word = "+s);
System.out.println("Reversed Word = "+w);
if (s.equalsIgnoreCase(w))
System.out.println("it is a palindrome as well as special word");
else if(s.charAt(0)==s.charAt(l-1))
System.out.println("it is only a  Specail word ");
else
System.out.println("it is not a palindrome or special word");
}
}