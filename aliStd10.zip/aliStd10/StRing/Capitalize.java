package StRing;

import java.util.*;
class Capitalize extends Q6_2018
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println(" enter a Statement");
String s =  sc.nextLine(); // "haPPy nEw yEaR 2017";
System.out.println(s);
s = s.toLowerCase()+" ";
String w = "";
String h ="";
for(int i=0;i<s.length(); i++)
{
char ch = s.charAt(i); //5
if(ch!=' ')
w = w+ch; 
else
{
    ch = w.charAt(0); //  h // n extracting first character
    ch = Character.toUpperCase(ch);// H // N
    h=h+ch+w.substring(1)+" "; // H
    w="";
}
}
System.out.println(h.trim());
}
}