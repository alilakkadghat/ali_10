package StRing;
import java.util.*;
class extractcharcter extends character_search
{
    public static void main () {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentence");
        String str=sc.nextLine();
        System.out.println("Enter word to be counted");
        char c=sc.next().charAt(0);
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch == c) {
                count++;
            }
        }
        System.out.println("Frequency of " + c + " = " + count);
    }
}