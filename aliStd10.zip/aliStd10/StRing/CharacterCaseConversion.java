package StRing;
class CharacterCaseConversion
{
public static void main()
{
String s = "Sachin Ramesh Tendulkar"; // storing a statement
System.out.println(s); // Sachin Ramesh Tendulkar
System.out.println(Character.toUpperCase('h')); // H
System.out.println(Character.toLowerCase('A'));  // a
char ch = s.charAt(1); // a
char x = Character.toUpperCase(ch);  // A
System.out.println(x);  // A
char y = Character.toLowerCase(s.charAt(0));  // S
System.out.println(y);  //s
}
}