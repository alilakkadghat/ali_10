package StRing;

import java.util.*;
class password
{
public static void main()
{
Scanner sc = new Scanner(System.in);
String p = "United@123";
System.out.println("Enter your password");
String sent = sc.nextLine(); // input and store a statement from the user
if(p.equals(sent))//p.equalsIgnoreCase(sent))
System.out.println("Correct password"); // print 
else
System.out.println("Incorrect Password.... try again");
}
}