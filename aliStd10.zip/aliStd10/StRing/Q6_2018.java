package StRing; 
import java.util.*;
class Q6_2018
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentences");
        String s = sc.nextLine();
        s=s.toLowerCase();
        s=" "+s;// hello world  
        String w="";
        for(int i=0;i<s.length();i++){
            if(s.charAt(i)==' '){
                w=w+" "+Character.toUpperCase(s.charAt(++i));
            }
            else if(s.charAt(i)!=' ')
                w=w+s.charAt(i);
        }
        System.out.println(w.trim());
    }

}
