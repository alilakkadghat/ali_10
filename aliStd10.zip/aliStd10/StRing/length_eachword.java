package StRing;
import java.util.*;
class length_eachword
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine(); //"Sachin Ramesh Tendulkar I love my country" 
s=s+" "; 
String w = "";
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);  //     
if(ch != ' ')
w = w + ch; // country
else
{
System.out.println(w+"    "+w.length());  
w="";
}    
} 
//System.out.println("Outside loop "+w);    
}      
}