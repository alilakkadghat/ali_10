package StRing;
import java.util.*;
class Q8_2019{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentence");
        String n=sc.nextLine();
        n=" "+n;
        n=n.toUpperCase();
        int c=0;
        for(int i = 0;i<n.length(); i=i+1)
        {
            if (n.charAt(i) == ' ' && n.charAt(i + 1) == 'A')
                c++;
        }
        System.out.println("Total number of word starting with 'A' is :"+c);
    }
}

