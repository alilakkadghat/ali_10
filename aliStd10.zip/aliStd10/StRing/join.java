package StRing;
import java.util.*;
class join
{
public static void main()
{
Scanner sc = new Scanner(System.in);
int c=0;
System.out.println("Enter a statement");    
String s = sc.nextLine(); //"Sachin Ramesh Tendulkar I love my country"
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);  
if(ch ==' ')
System.out.println();
else
System.out.print(ch); 
}
}
}