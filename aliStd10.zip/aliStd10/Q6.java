 
import java.util.*;
class Q6{
    public static void main(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentence");
        String n[]=new String[10];
        
        for(int i = 0;i<n.length; i=i+1)
        {
         n[i]=sc.next();
        }
        for(int i = 0;i<n.length; i=i+1)
        {
            if (n[i].startsWith("A")||n[i].startsWith("a")&&n[i].endsWith("A")||n[i].endsWith("a"))
                System.out.println(n[i]);
        }
    }
}

