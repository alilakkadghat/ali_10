import java.util.*;
class fac
{
    public static int n;
    private static void accept()
 {
     Scanner sc=new Scanner(System.in);
System.out.println("Enter an Integer number:");
n=sc.nextInt();
}
public static void calc_print()
{
int x=1;
accept();
for(int i=1;i<=n;i++)
{
x=x*i;
}
System.out.println("The factorial of the number "+n+"! is: "+ x);
}
}
