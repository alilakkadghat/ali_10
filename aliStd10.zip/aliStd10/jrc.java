import java.util.*;
class jrc{
    public static void main(){
        int x=7;
     while(x>5){
        System.out.println(x);
         System.out.println(--x+2); 
         System.out.println(x--);
         double y=2.2;
         System.out.println(y%2);
         
    }
    }	

}