 
import java.util.*;
class ICSE_Q5
{
public static void main()
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter a statement");    
String s = sc.nextLine();
s=s+" ";
String w="",h="";
for(int i = 0;i<s.length(); i=i+1)
{
char ch = s.charAt(i);       
if(ch!=' ')
w=w+ch;
else{
    for(int j =0;i<w.length(); j=j+1)
{
char sh = w.charAt(j); 
if(Character.isLetter(sh))
{
 if(Character.isUpperCase(sh)){
sh=Character.toLowerCase(sh);
h=h+sh;
}
else if(Character.isLowerCase(sh)){
sh=Character.toUpperCase(sh);
h=h+sh;
}
}
else
h=h+sh;
} 
}
System.out.println(h);
}
}
}
