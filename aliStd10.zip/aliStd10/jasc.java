import java.util.*;
class jasc{
    public static void main(){
    int x=2,y=4,z=1;
    int result=(++z)+y+(++x)+(z++);
System.out.println(result);

String f = "Computer world";
String g = "Computer Applications";
System.out.println (f.indexOf(g.charAt(4)));
}
public static void main1(){
    String A= "20", B="22";
int a= Integer.parseInt(A);
int b= Integer.parseInt(B);
System.out.println("hey  "+a+b+"\n"+(a+b));

String x="Ziva";
String y="Pearly";
System.out.print(x.compareTo(y));
System.out.println(x.replace('a','u'));

int X[ ] = {8, 5, 0, 1, 3};
System.out.println(X.length + Math.pow(X[1], X[2]));
}
}