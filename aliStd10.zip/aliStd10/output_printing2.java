class output_printing2
{
    public static void main1(){
        //1 State how many times will the following loop execute and also state the output
        int i , j ,ctr =0 ;
        for(i = 1 ; i <=5 ; i = i + 2)
        {
            for ( j = 1 ; j<= i ;j= j + 2)
            {
                ctr = ctr+ 5;
            }
        }
        System.out.println( ctr);
    }
    public static void main2(){
        //Question 2
        //State the output 0f following snippet
        int i , j ;
        for(i = 1 ; i <=5 ; i = i + 2)
        {
            for ( j = 2 ; j<= i ;j= j + 2)
            {
                System.out.println(i*j);
            }
        }
    }
    public static void main3(){
       // Question 3
       // State the output of the following snippet
        int i,j;
        for(i=5;i>=1;i--)
        {
            for(j=1;j<=i;j++)
            {
                if((j%2)==0)
                    System.out.print("# ");
                else
                    System.out.print("@ ");

            }
            System.out.println();
        }
    }
}