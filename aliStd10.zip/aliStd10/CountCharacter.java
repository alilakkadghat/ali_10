 import java.util.*;
class CountCharacter    
{    
    public static void main() {   
        Scanner sc=new Scanner(System.in);
         System.out.println("enter a sentence");
        String a=sc.nextLine(); 
        int count = 0;    

        for(int i = 0; i <a.length(); i++) {    
            if(a.charAt(i) != ' ')    
                count++;    
        }    
        System.out.println("Total number of characters in a string: " + count);    
    }    
}     