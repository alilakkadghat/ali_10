class octal1
{
    public static void main()
    {
       System.out.println(000052);//octal no system
       System.out.println(0x20);//hexadecimal no.system
       System.out.println("Hello\n");
       System.out.print("world");
    }
}
