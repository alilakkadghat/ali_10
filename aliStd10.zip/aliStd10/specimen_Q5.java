 
import java.util.*;
/*Define a class to accept two strings, convert them into uppercase, check and display
whether two strings are equal or not, if the two 
strings are not equal, print the string with
the highest length or print the message both the 
strings are of equal length.*/

class specimen_Q5
{
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a sentences");
        String s = sc.nextLine();
        System.out.println("Enter another sentences");
        String s1 = sc.nextLine();
        s=s.toUpperCase(); 
        s1=s1.toUpperCase(); 
        if(s.equals(s1))
            System.out.println("Strings are Equal");
        else{
            System.out.println("Strings are not Equal\nString with highest length is");
            if(s.length()>s1.length())
                System.out.println(s);
            else if(s1.length()>s.length())
                System.out.println(s1);
                else
                System.out.println("Strings are of Equal length");
        }
    }
}