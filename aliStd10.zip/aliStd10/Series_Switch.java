import java.util.*;
class Series_Switch
{
public static void main()
{
    int ch;
do
{
Scanner sc = new Scanner(System.in);
System.out.println("    Menu    ");
System.out.println("Type 1 For odd numbers series ");
System.out.println("Type 2 For Even numbers series ");
System.out.println("Type 3 to Quit ");
ch = sc.nextInt();
switch(ch)
{
case 1:
System.out.println("Enter series limit ");
int n = sc.nextInt();
    for (int i=1;i<=n;i=i+2)   
    { 
    System.out.println(i);
    }
break;
case 2:
System.out.println("Enter series limit ");
int x = sc.nextInt();
    for (int i=2;i<=x;i=i+2)   
    { 
    System.out.println(i); 
    }
break;
case 3:
System.out.println("Thank you........ ");
break;
default:
    System.out.println("Wrong Input !! ");
}
}while(ch !=3);
}
}