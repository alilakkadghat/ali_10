class bre_con
{
    public static void main() { 
        for (int i = 50; i>=0; i=i-10)
        {
            if(i==30)
            continue;
            System.out.println(i);
            //System.out.println("generated");
        } 
    }
        public static void mass() {
          for (int i = 50; i>=0; i=i-10)
        {
            if(i==30)
            break;
            System.out.println(i);
            //System.out.println("generated");
        } 
    } 
}

